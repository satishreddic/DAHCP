Per-dataset paired comparison of DACHP-v2 (ours) vs each method on Test Silhouette (2-D) over the 5 held-out splits; Holm correction across methods within each dataset.

| Dataset | vs | Mean Δ | 95% boot CI | p (paired t) | p Holm | Sig. |
|---|---|---|---|---|---|---|
| Breast Cancer | DACHP (ours) | +0.022 | [+0.015, +0.029] | 0.0070 | 0.0418 | yes |
| Breast Cancer | SupCon (same enc.) | +0.050 | [+0.028, +0.075] | 0.0201 | 0.0418 | yes |
| Breast Cancer | Triplet (batch-hard) | +0.056 | [+0.038, +0.077] | 0.0070 | 0.0418 | yes |
| Breast Cancer | Proxy-Anchor | +0.047 | [+0.022, +0.069] | 0.0249 | 0.0418 | yes |
| Breast Cancer | ArcFace | +0.094 | [+0.068, +0.119] | 0.0027 | 0.0218 | yes |
| Breast Cancer | CosFace | +0.059 | [+0.037, +0.081] | 0.0098 | 0.0418 | yes |
| Breast Cancer | CE-MLP (norm.) | +0.125 | [+0.113, +0.138] | 0.0001 | 0.0008 | yes |
| Breast Cancer | Sup-UMAP (tuned) | +0.156 | [+0.121, +0.192] | 0.0016 | 0.0140 | yes |
| Breast Cancer | Sup-UMAP (tuned, 16-D) | +0.098 | [+0.069, +0.127] | 0.0041 | 0.0284 | yes |
| Breast Cancer | Sup-UMAP (default) | +0.179 | [+0.110, +0.247] | 0.0100 | 0.0418 | yes |
| Breast Cancer | LDA | +0.274 | [+0.233, +0.313] | 0.0003 | 0.0029 | yes |
| Breast Cancer | PCA | +0.460 | [+0.424, +0.485] | 0.0000 | 0.0002 | yes |
| Digits | DACHP (ours) | +0.005 | [-0.065, +0.110] | 0.9220 | 0.9220 | no |
| Digits | SupCon (same enc.) | +0.131 | [+0.098, +0.174] | 0.0041 | 0.0081 | yes |
| Digits | Triplet (batch-hard) | +0.294 | [+0.256, +0.325] | 0.0001 | 0.0009 | yes |
| Digits | Proxy-Anchor | +0.247 | [+0.223, +0.270] | 0.0001 | 0.0005 | yes |
| Digits | ArcFace | +0.243 | [+0.202, +0.293] | 0.0008 | 0.0038 | yes |
| Digits | CosFace | +0.302 | [+0.231, +0.374] | 0.0016 | 0.0049 | yes |
| Digits | CE-MLP (norm.) | +0.344 | [+0.292, +0.395] | 0.0003 | 0.0020 | yes |
| Digits | Sup-UMAP (tuned) | -0.234 | [-0.259, -0.210] | 0.0001 | 0.0007 | yes |
| Digits | Sup-UMAP (tuned, 16-D) | -0.166 | [-0.195, -0.130] | 0.0011 | 0.0043 | yes |
| Digits | Sup-UMAP (default) | -0.224 | [-0.257, -0.198] | 0.0002 | 0.0016 | yes |
| Digits | LDA | +0.312 | [+0.309, +0.314] | 0.0000 | 0.0000 | yes |
| Digits | PCA | +0.408 | [+0.377, +0.435] | 0.0000 | 0.0002 | yes |
| Mice Protein | DACHP (ours) | -0.123 | [-0.178, -0.078] | 0.0124 | 0.1361 | no |
| Mice Protein | SupCon (same enc.) | -0.134 | [-0.204, -0.063] | 0.0285 | 0.2846 | no |
| Mice Protein | Triplet (batch-hard) | -0.146 | [-0.240, -0.064] | 0.0442 | 0.3533 | no |
| Mice Protein | Proxy-Anchor | +0.054 | [+0.010, +0.107] | 0.1154 | 0.7182 | no |
| Mice Protein | ArcFace | -0.047 | [-0.110, +0.027] | 0.3012 | 1.0000 | no |
| Mice Protein | CosFace | -0.043 | [-0.089, +0.022] | 0.2601 | 1.0000 | no |
| Mice Protein | CE-MLP (norm.) | -0.058 | [-0.115, -0.000] | 0.1546 | 0.7730 | no |
| Mice Protein | Sup-UMAP (tuned) | +0.004 | [-0.068, +0.076] | 0.9279 | 1.0000 | no |
| Mice Protein | Sup-UMAP (tuned, 16-D) | +0.126 | [+0.099, +0.157] | 0.0015 | 0.0181 | yes |
| Mice Protein | Sup-UMAP (default) | +0.033 | [-0.016, +0.082] | 0.2943 | 1.0000 | no |
| Mice Protein | LDA | -0.157 | [-0.233, -0.072] | 0.0295 | 0.2846 | no |
| Mice Protein | PCA | +0.066 | [+0.012, +0.119] | 0.1026 | 0.7182 | no |
| Annealing | DACHP (ours) | -0.006 | [-0.119, +0.056] | 0.9213 | 0.9213 | no |
| Annealing | SupCon (same enc.) | +0.055 | [+0.037, +0.075] | 0.0070 | 0.0384 | yes |
| Annealing | Triplet (batch-hard) | +0.368 | [+0.246, +0.462] | 0.0042 | 0.0369 | yes |
| Annealing | Proxy-Anchor | +0.297 | [+0.209, +0.366] | 0.0028 | 0.0305 | yes |
| Annealing | ArcFace | +0.165 | [+0.092, +0.297] | 0.0672 | 0.2017 | no |
| Annealing | CosFace | +0.126 | [+0.062, +0.236] | 0.0811 | 0.2017 | no |
| Annealing | CE-MLP (norm.) | +0.377 | [+0.184, +0.599] | 0.0302 | 0.1210 | no |
| Annealing | Sup-UMAP (tuned) | +0.571 | [+0.396, +0.678] | 0.0028 | 0.0305 | yes |
| Annealing | Sup-UMAP (tuned, 16-D) | +0.639 | [+0.417, +0.834] | 0.0059 | 0.0384 | yes |
| Annealing | Sup-UMAP (default) | +0.568 | [+0.375, +0.679] | 0.0041 | 0.0369 | yes |
| Annealing | LDA | +0.564 | [+0.366, +0.750] | 0.0055 | 0.0384 | yes |
| Annealing | PCA | +0.848 | [+0.682, +0.948] | 0.0005 | 0.0061 | yes |
| COIL-20 | DACHP (ours) | +0.066 | [+0.037, +0.100] | 0.0222 | 0.0443 | yes |
| COIL-20 | SupCon (same enc.) | +0.253 | [+0.195, +0.304] | 0.0015 | 0.0059 | yes |
| COIL-20 | Triplet (batch-hard) | +0.189 | [+0.150, +0.229] | 0.0011 | 0.0054 | yes |
| COIL-20 | Proxy-Anchor | +0.585 | [+0.531, +0.634] | 0.0000 | 0.0004 | yes |
| COIL-20 | ArcFace | +0.423 | [+0.369, +0.489] | 0.0003 | 0.0020 | yes |
| COIL-20 | CosFace | +0.383 | [+0.342, +0.439] | 0.0002 | 0.0016 | yes |
| COIL-20 | CE-MLP (norm.) | +0.372 | [+0.306, +0.436] | 0.0006 | 0.0034 | yes |
| COIL-20 | Sup-UMAP (tuned) | +0.454 | [+0.380, +0.527] | 0.0004 | 0.0026 | yes |
| COIL-20 | Sup-UMAP (tuned, 16-D) | +0.233 | [+0.170, +0.280] | 0.0018 | 0.0059 | yes |
| COIL-20 | Sup-UMAP (default) | +0.048 | [-0.003, +0.089] | 0.1572 | 0.1572 | no |
| COIL-20 | LDA | +0.622 | [+0.594, +0.649] | 0.0000 | 0.0000 | yes |
| COIL-20 | PCA | +0.704 | [+0.669, +0.735] | 0.0000 | 0.0000 | yes |
| CNAE-9 | DACHP (ours) | -0.134 | [-0.185, -0.073] | 0.0160 | 0.1120 | no |
| CNAE-9 | SupCon (same enc.) | -0.097 | [-0.130, -0.064] | 0.0068 | 0.0615 | no |
| CNAE-9 | Triplet (batch-hard) | +0.092 | [+0.051, +0.142] | 0.0258 | 0.1363 | no |
| CNAE-9 | Proxy-Anchor | +0.006 | [-0.039, +0.060] | 0.8307 | 0.8307 | no |
| CNAE-9 | ArcFace | +0.053 | [+0.004, +0.102] | 0.1349 | 0.4048 | no |
| CNAE-9 | CosFace | +0.037 | [+0.001, +0.081] | 0.1782 | 0.4048 | no |
| CNAE-9 | CE-MLP (norm.) | +0.119 | [+0.046, +0.193] | 0.0449 | 0.1795 | no |
| CNAE-9 | Sup-UMAP (tuned) | -0.144 | [-0.219, -0.079] | 0.0227 | 0.1363 | no |
| CNAE-9 | Sup-UMAP (tuned, 16-D) | -0.165 | [-0.227, -0.109] | 0.0080 | 0.0637 | no |
| CNAE-9 | Sup-UMAP (default) | -0.175 | [-0.205, -0.147] | 0.0004 | 0.0047 | yes |
| CNAE-9 | LDA | +0.413 | [+0.340, +0.489] | 0.0007 | 0.0066 | yes |
| CNAE-9 | PCA | +0.543 | [+0.500, +0.589] | 0.0000 | 0.0003 | yes |
| MNIST | DACHP (ours) | -0.013 | [-0.073, +0.030] | 0.7044 | 1.0000 | no |
| MNIST | SupCon (same enc.) | +0.210 | [+0.168, +0.240] | 0.0006 | 0.0042 | yes |
| MNIST | Triplet (batch-hard) | +0.315 | [+0.258, +0.400] | 0.0019 | 0.0094 | yes |
| MNIST | Proxy-Anchor | +0.444 | [+0.386, +0.491] | 0.0001 | 0.0011 | yes |
| MNIST | ArcFace | +0.425 | [+0.376, +0.473] | 0.0001 | 0.0011 | yes |
| MNIST | CosFace | +0.429 | [+0.386, +0.473] | 0.0001 | 0.0007 | yes |
| MNIST | CE-MLP (norm.) | +0.295 | [+0.233, +0.360] | 0.0013 | 0.0077 | yes |
| MNIST | Sup-UMAP (tuned) | +0.030 | [-0.023, +0.073] | 0.3347 | 1.0000 | no |
| MNIST | Sup-UMAP (tuned, 16-D) | +0.091 | [+0.035, +0.148] | 0.0508 | 0.2033 | no |
| MNIST | Sup-UMAP (default) | +0.030 | [-0.023, +0.073] | 0.3347 | 1.0000 | no |
| MNIST | LDA | +0.610 | [+0.581, +0.639] | 0.0000 | 0.0001 | yes |
| MNIST | PCA | +0.726 | [+0.669, +0.776] | 0.0000 | 0.0002 | yes |
| Fashion-MNIST | DACHP (ours) | +0.030 | [-0.052, +0.115] | 0.5326 | 0.7798 | no |
| Fashion-MNIST | SupCon (same enc.) | +0.086 | [+0.011, +0.148] | 0.0954 | 0.2861 | no |
| Fashion-MNIST | Triplet (batch-hard) | +0.366 | [+0.277, +0.429] | 0.0013 | 0.0106 | yes |
| Fashion-MNIST | Proxy-Anchor | +0.175 | [+0.104, +0.246] | 0.0131 | 0.0918 | no |
| Fashion-MNIST | ArcFace | +0.357 | [+0.300, +0.406] | 0.0003 | 0.0036 | yes |
| Fashion-MNIST | CosFace | +0.369 | [+0.298, +0.438] | 0.0008 | 0.0075 | yes |
| Fashion-MNIST | CE-MLP (norm.) | +0.137 | [+0.058, +0.204] | 0.0327 | 0.1306 | no |
| Fashion-MNIST | Sup-UMAP (tuned) | +0.101 | [+0.054, +0.140] | 0.0145 | 0.0918 | no |
| Fashion-MNIST | Sup-UMAP (tuned, 16-D) | +0.138 | [+0.068, +0.199] | 0.0209 | 0.1045 | no |
| Fashion-MNIST | Sup-UMAP (default) | +0.031 | [-0.031, +0.075] | 0.3899 | 0.7798 | no |
| Fashion-MNIST | LDA | +0.301 | [+0.247, +0.349] | 0.0005 | 0.0048 | yes |
| Fashion-MNIST | PCA | +0.446 | [+0.398, +0.490] | 0.0001 | 0.0008 | yes |
| HAR | DACHP (ours) | +0.012 | [+0.000, +0.027] | 0.1944 | 0.1944 | no |
| HAR | SupCon (same enc.) | +0.122 | [+0.061, +0.218] | 0.0627 | 0.1253 | no |
| HAR | Triplet (batch-hard) | +0.283 | [+0.230, +0.344] | 0.0010 | 0.0048 | yes |
| HAR | Proxy-Anchor | +0.143 | [+0.131, +0.157] | 0.0000 | 0.0004 | yes |
| HAR | ArcFace | +0.512 | [+0.471, +0.559] | 0.0000 | 0.0003 | yes |
| HAR | CosFace | +0.353 | [+0.312, +0.402] | 0.0002 | 0.0010 | yes |
| HAR | CE-MLP (norm.) | +0.203 | [+0.158, +0.255] | 0.0021 | 0.0082 | yes |
| HAR | Sup-UMAP (tuned) | +0.230 | [+0.207, +0.255] | 0.0001 | 0.0006 | yes |
| HAR | Sup-UMAP (tuned, 16-D) | +0.273 | [+0.221, +0.351] | 0.0021 | 0.0082 | yes |
| HAR | Sup-UMAP (default) | +0.272 | [+0.252, +0.296] | 0.0000 | 0.0002 | yes |
| HAR | LDA | +0.731 | [+0.720, +0.742] | 0.0000 | 0.0000 | yes |
| HAR | PCA | +0.918 | [+0.909, +0.930] | 0.0000 | 0.0000 | yes |
| ISOLET | DACHP (ours) | +0.055 | [-0.050, +0.133] | 0.3500 | 1.0000 | no |
| ISOLET | SupCon (same enc.) | +0.027 | [-0.027, +0.072] | 0.3945 | 1.0000 | no |
| ISOLET | Triplet (batch-hard) | +0.256 | [+0.220, +0.299] | 0.0004 | 0.0040 | yes |
| ISOLET | Proxy-Anchor | -0.018 | [-0.095, +0.032] | 0.6675 | 1.0000 | no |
| ISOLET | ArcFace | +0.319 | [+0.286, +0.364] | 0.0002 | 0.0017 | yes |
| ISOLET | CosFace | +0.215 | [+0.159, +0.271] | 0.0029 | 0.0229 | yes |
| ISOLET | CE-MLP (norm.) | +0.153 | [+0.092, +0.206] | 0.0091 | 0.0548 | no |
| ISOLET | Sup-UMAP (tuned) | -0.076 | [-0.120, -0.021] | 0.0579 | 0.2894 | no |
| ISOLET | Sup-UMAP (tuned, 16-D) | +0.030 | [-0.015, +0.079] | 0.3259 | 1.0000 | no |
| ISOLET | Sup-UMAP (default) | -0.151 | [-0.189, -0.097] | 0.0052 | 0.0361 | yes |
| ISOLET | LDA | +0.352 | [+0.316, +0.401] | 0.0001 | 0.0014 | yes |
| ISOLET | PCA | +0.469 | [+0.432, +0.517] | 0.0000 | 0.0005 | yes |
| Olivetti Faces | DACHP (ours) | -0.006 | [-0.110, +0.090] | 0.9161 | 1.0000 | no |
| Olivetti Faces | SupCon (same enc.) | +0.092 | [+0.038, +0.154] | 0.0532 | 0.4253 | no |
| Olivetti Faces | Triplet (batch-hard) | -0.051 | [-0.192, +0.061] | 0.5259 | 1.0000 | no |
| Olivetti Faces | Proxy-Anchor | +0.163 | [+0.070, +0.262] | 0.0406 | 0.3654 | no |
| Olivetti Faces | ArcFace | +0.169 | [+0.083, +0.276] | 0.0360 | 0.3604 | no |
| Olivetti Faces | CosFace | +0.156 | [+0.061, +0.274] | 0.0687 | 0.4812 | no |
| Olivetti Faces | CE-MLP (norm.) | +0.199 | [+0.140, +0.269] | 0.0062 | 0.0686 | no |
| Olivetti Faces | Sup-UMAP (tuned) | -0.139 | [-0.243, -0.018] | 0.0864 | 0.5185 | no |
| Olivetti Faces | Sup-UMAP (tuned, 16-D) | -0.023 | [-0.105, +0.077] | 0.6854 | 1.0000 | no |
| Olivetti Faces | Sup-UMAP (default) | +0.030 | [-0.025, +0.088] | 0.3942 | 1.0000 | no |
| Olivetti Faces | LDA | +0.060 | [-0.049, +0.166] | 0.3687 | 1.0000 | no |
| Olivetti Faces | PCA | +0.311 | [+0.218, +0.411] | 0.0044 | 0.0532 | no |
