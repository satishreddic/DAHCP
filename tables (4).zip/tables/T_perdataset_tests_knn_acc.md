Per-dataset paired comparison of DACHP-v2 (ours) vs each method on Test 5-NN accuracy over the 5 held-out splits; Holm correction across methods within each dataset.

| Dataset | vs | Mean Δ | 95% boot CI | p (paired t) | p Holm | Sig. |
|---|---|---|---|---|---|---|
| Breast Cancer | DACHP (ours) | +0.002 | [+0.000, +0.005] | 0.3739 | 1.0000 | no |
| Breast Cancer | SupCon (same enc.) | +0.004 | [-0.004, +0.011] | 0.4766 | 1.0000 | no |
| Breast Cancer | Triplet (batch-hard) | +0.012 | [+0.005, +0.021] | 0.0516 | 0.6193 | no |
| Breast Cancer | Proxy-Anchor | +0.000 | [-0.009, +0.007] | 1.0000 | 1.0000 | no |
| Breast Cancer | ArcFace | +0.005 | [-0.004, +0.012] | 0.3046 | 1.0000 | no |
| Breast Cancer | CosFace | +0.005 | [-0.004, +0.012] | 0.3046 | 1.0000 | no |
| Breast Cancer | CE-MLP (norm.) | +0.002 | [-0.004, +0.007] | 0.6213 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (tuned) | +0.012 | [+0.002, +0.023] | 0.1079 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (tuned, 16-D) | +0.012 | [+0.002, +0.023] | 0.1079 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (default) | +0.018 | [+0.005, +0.035] | 0.1292 | 1.0000 | no |
| Breast Cancer | LDA | +0.014 | [+0.005, +0.023] | 0.0560 | 0.6193 | no |
| Breast Cancer | PCA | +0.009 | [+0.000, +0.019] | 0.1890 | 1.0000 | no |
| Digits | DACHP (ours) | +0.006 | [+0.000, +0.012] | 0.1778 | 0.9657 | no |
| Digits | SupCon (same enc.) | -0.007 | [-0.011, -0.006] | 0.0123 | 0.1232 | no |
| Digits | Triplet (batch-hard) | +0.001 | [-0.006, +0.007] | 0.7717 | 1.0000 | no |
| Digits | Proxy-Anchor | -0.009 | [-0.012, -0.006] | 0.0054 | 0.0616 | no |
| Digits | ArcFace | +0.001 | [-0.006, +0.006] | 0.7489 | 1.0000 | no |
| Digits | CosFace | +0.001 | [-0.007, +0.006] | 0.8928 | 1.0000 | no |
| Digits | CE-MLP (norm.) | -0.010 | [-0.014, -0.006] | 0.0178 | 0.1603 | no |
| Digits | Sup-UMAP (tuned) | +0.006 | [-0.001, +0.012] | 0.1609 | 0.9657 | no |
| Digits | Sup-UMAP (tuned, 16-D) | +0.005 | [-0.001, +0.009] | 0.1671 | 0.9657 | no |
| Digits | Sup-UMAP (default) | +0.026 | [+0.017, +0.032] | 0.0051 | 0.0616 | no |
| Digits | LDA | +0.007 | [+0.003, +0.009] | 0.0240 | 0.1776 | no |
| Digits | PCA | +0.012 | [+0.006, +0.017] | 0.0222 | 0.1776 | no |
| Mice Protein | DACHP (ours) | +0.036 | [+0.003, +0.074] | 0.1476 | 0.8858 | no |
| Mice Protein | SupCon (same enc.) | -0.012 | [-0.035, +0.012] | 0.4464 | 1.0000 | no |
| Mice Protein | Triplet (batch-hard) | +0.016 | [-0.017, +0.066] | 0.5524 | 1.0000 | no |
| Mice Protein | Proxy-Anchor | -0.010 | [-0.045, +0.025] | 0.6327 | 1.0000 | no |
| Mice Protein | ArcFace | +0.044 | [+0.014, +0.075] | 0.0792 | 0.5544 | no |
| Mice Protein | CosFace | +0.034 | [+0.000, +0.070] | 0.1845 | 0.9227 | no |
| Mice Protein | CE-MLP (norm.) | +0.045 | [+0.014, +0.076] | 0.0633 | 0.5065 | no |
| Mice Protein | Sup-UMAP (tuned) | +0.231 | [+0.207, +0.255] | 0.0001 | 0.0006 | yes |
| Mice Protein | Sup-UMAP (tuned, 16-D) | +0.242 | [+0.219, +0.265] | 0.0000 | 0.0005 | yes |
| Mice Protein | Sup-UMAP (default) | +0.231 | [+0.221, +0.239] | 0.0000 | 0.0000 | yes |
| Mice Protein | LDA | -0.034 | [-0.090, +0.025] | 0.3701 | 1.0000 | no |
| Mice Protein | PCA | +0.245 | [+0.227, +0.273] | 0.0001 | 0.0006 | yes |
| Annealing | DACHP (ours) | +0.002 | [+0.000, +0.004] | 0.1778 | 1.0000 | no |
| Annealing | SupCon (same enc.) | -0.003 | [-0.008, +0.000] | 0.2080 | 1.0000 | no |
| Annealing | Triplet (batch-hard) | +0.004 | [+0.001, +0.008] | 0.0993 | 0.7944 | no |
| Annealing | Proxy-Anchor | -0.007 | [-0.016, +0.000] | 0.2080 | 1.0000 | no |
| Annealing | ArcFace | -0.004 | [-0.013, +0.002] | 0.4050 | 1.0000 | no |
| Annealing | CosFace | -0.004 | [-0.011, +0.000] | 0.2420 | 1.0000 | no |
| Annealing | CE-MLP (norm.) | -0.003 | [-0.011, +0.004] | 0.5012 | 1.0000 | no |
| Annealing | Sup-UMAP (tuned) | +0.037 | [+0.026, +0.050] | 0.0076 | 0.0686 | no |
| Annealing | Sup-UMAP (tuned, 16-D) | +0.040 | [+0.032, +0.049] | 0.0008 | 0.0101 | yes |
| Annealing | Sup-UMAP (default) | +0.041 | [+0.031, +0.051] | 0.0020 | 0.0199 | yes |
| Annealing | LDA | +0.000 | [-0.010, +0.010] | 1.0000 | 1.0000 | no |
| Annealing | PCA | +0.034 | [+0.028, +0.043] | 0.0015 | 0.0164 | yes |
| COIL-20 | DACHP (ours) | +0.001 | [-0.003, +0.006] | 0.8149 | 1.0000 | no |
| COIL-20 | SupCon (same enc.) | -0.001 | [-0.005, +0.002] | 0.5415 | 1.0000 | no |
| COIL-20 | Triplet (batch-hard) | -0.001 | [-0.007, +0.004] | 0.6885 | 1.0000 | no |
| COIL-20 | Proxy-Anchor | -0.003 | [-0.006, -0.001] | 0.0890 | 0.6231 | no |
| COIL-20 | ArcFace | +0.000 | [-0.002, +0.002] | 1.0000 | 1.0000 | no |
| COIL-20 | CosFace | -0.002 | [-0.005, +0.000] | 0.2080 | 1.0000 | no |
| COIL-20 | CE-MLP (norm.) | -0.003 | [-0.006, +0.001] | 0.2420 | 1.0000 | no |
| COIL-20 | Sup-UMAP (tuned) | +0.044 | [+0.032, +0.056] | 0.0033 | 0.0333 | yes |
| COIL-20 | Sup-UMAP (tuned, 16-D) | +0.029 | [+0.019, +0.042] | 0.0107 | 0.0962 | no |
| COIL-20 | Sup-UMAP (default) | +0.072 | [+0.058, +0.086] | 0.0009 | 0.0114 | yes |
| COIL-20 | LDA | +0.073 | [+0.054, +0.092] | 0.0026 | 0.0283 | yes |
| COIL-20 | PCA | +0.016 | [+0.007, +0.025] | 0.0377 | 0.3013 | no |
| CNAE-9 | DACHP (ours) | +0.003 | [-0.004, +0.008] | 0.4676 | 1.0000 | no |
| CNAE-9 | SupCon (same enc.) | -0.006 | [-0.021, +0.005] | 0.4310 | 1.0000 | no |
| CNAE-9 | Triplet (batch-hard) | -0.010 | [-0.018, -0.002] | 0.0858 | 0.5149 | no |
| CNAE-9 | Proxy-Anchor | -0.009 | [-0.013, -0.006] | 0.0111 | 0.0885 | no |
| CNAE-9 | ArcFace | +0.003 | [-0.005, +0.010] | 0.5529 | 1.0000 | no |
| CNAE-9 | CosFace | +0.000 | [-0.008, +0.008] | 1.0000 | 1.0000 | no |
| CNAE-9 | CE-MLP (norm.) | -0.002 | [-0.013, +0.009] | 0.7839 | 1.0000 | no |
| CNAE-9 | Sup-UMAP (tuned) | +0.093 | [+0.073, +0.119] | 0.0023 | 0.0226 | yes |
| CNAE-9 | Sup-UMAP (tuned, 16-D) | +0.043 | [+0.028, +0.061] | 0.0111 | 0.0885 | no |
| CNAE-9 | Sup-UMAP (default) | +0.080 | [+0.072, +0.091] | 0.0002 | 0.0017 | yes |
| CNAE-9 | LDA | +0.079 | [+0.056, +0.097] | 0.0026 | 0.0237 | yes |
| CNAE-9 | PCA | +0.119 | [+0.109, +0.129] | 0.0000 | 0.0003 | yes |
| MNIST | DACHP (ours) | +0.002 | [-0.001, +0.006] | 0.3174 | 0.9522 | no |
| MNIST | SupCon (same enc.) | -0.002 | [-0.004, -0.000] | 0.1202 | 0.4810 | no |
| MNIST | Triplet (batch-hard) | -0.005 | [-0.008, -0.002] | 0.0436 | 0.2181 | no |
| MNIST | Proxy-Anchor | -0.006 | [-0.009, -0.005] | 0.0052 | 0.0363 | yes |
| MNIST | ArcFace | -0.001 | [-0.002, +0.001] | 0.4256 | 0.9522 | no |
| MNIST | CosFace | -0.002 | [-0.005, +0.002] | 0.4004 | 0.9522 | no |
| MNIST | CE-MLP (norm.) | -0.007 | [-0.010, -0.004] | 0.0204 | 0.1225 | no |
| MNIST | Sup-UMAP (tuned) | +0.038 | [+0.035, +0.041] | 0.0000 | 0.0003 | yes |
| MNIST | Sup-UMAP (tuned, 16-D) | +0.032 | [+0.028, +0.038] | 0.0003 | 0.0026 | yes |
| MNIST | Sup-UMAP (default) | +0.038 | [+0.035, +0.041] | 0.0000 | 0.0003 | yes |
| MNIST | LDA | +0.080 | [+0.076, +0.083] | 0.0000 | 0.0000 | yes |
| MNIST | PCA | +0.040 | [+0.035, +0.044] | 0.0001 | 0.0009 | yes |
| Fashion-MNIST | DACHP (ours) | -0.003 | [-0.005, -0.001] | 0.0777 | 0.3110 | no |
| Fashion-MNIST | SupCon (same enc.) | -0.006 | [-0.008, -0.005] | 0.0007 | 0.0049 | yes |
| Fashion-MNIST | Triplet (batch-hard) | +0.014 | [+0.012, +0.017] | 0.0007 | 0.0049 | yes |
| Fashion-MNIST | Proxy-Anchor | -0.001 | [-0.003, +0.001] | 0.4316 | 0.8632 | no |
| Fashion-MNIST | ArcFace | +0.003 | [+0.000, +0.006] | 0.1046 | 0.3138 | no |
| Fashion-MNIST | CosFace | -0.000 | [-0.004, +0.003] | 0.8951 | 0.8951 | no |
| Fashion-MNIST | CE-MLP (norm.) | -0.011 | [-0.016, -0.008] | 0.0109 | 0.0544 | no |
| Fashion-MNIST | Sup-UMAP (tuned) | +0.059 | [+0.052, +0.066] | 0.0001 | 0.0010 | yes |
| Fashion-MNIST | Sup-UMAP (tuned, 16-D) | +0.052 | [+0.046, +0.056] | 0.0000 | 0.0005 | yes |
| Fashion-MNIST | Sup-UMAP (default) | +0.060 | [+0.052, +0.067] | 0.0001 | 0.0011 | yes |
| Fashion-MNIST | LDA | +0.059 | [+0.054, +0.064] | 0.0000 | 0.0003 | yes |
| Fashion-MNIST | PCA | +0.065 | [+0.058, +0.073] | 0.0001 | 0.0010 | yes |
| HAR | DACHP (ours) | -0.001 | [-0.002, -0.001] | 0.0486 | 0.2432 | no |
| HAR | SupCon (same enc.) | -0.001 | [-0.002, +0.001] | 0.3572 | 0.8940 | no |
| HAR | Triplet (batch-hard) | -0.002 | [-0.003, -0.001] | 0.0491 | 0.2432 | no |
| HAR | Proxy-Anchor | -0.002 | [-0.002, -0.001] | 0.0021 | 0.0170 | yes |
| HAR | ArcFace | -0.000 | [-0.001, +0.000] | 0.2980 | 0.8940 | no |
| HAR | CosFace | -0.000 | [-0.001, +0.001] | 0.5660 | 0.8940 | no |
| HAR | CE-MLP (norm.) | -0.002 | [-0.003, -0.001] | 0.0402 | 0.2410 | no |
| HAR | Sup-UMAP (tuned) | +0.037 | [+0.036, +0.038] | 0.0000 | 0.0000 | yes |
| HAR | Sup-UMAP (tuned, 16-D) | +0.038 | [+0.037, +0.039] | 0.0000 | 0.0000 | yes |
| HAR | Sup-UMAP (default) | +0.059 | [+0.055, +0.063] | 0.0000 | 0.0001 | yes |
| HAR | LDA | +0.007 | [+0.005, +0.008] | 0.0030 | 0.0209 | yes |
| HAR | PCA | +0.090 | [+0.086, +0.093] | 0.0000 | 0.0000 | yes |
| ISOLET | DACHP (ours) | -0.001 | [-0.002, +0.000] | 0.2455 | 0.6298 | no |
| ISOLET | SupCon (same enc.) | -0.003 | [-0.005, -0.000] | 0.1260 | 0.6298 | no |
| ISOLET | Triplet (batch-hard) | -0.002 | [-0.005, -0.000] | 0.1561 | 0.6298 | no |
| ISOLET | Proxy-Anchor | +0.001 | [-0.003, +0.003] | 0.7415 | 0.7415 | no |
| ISOLET | ArcFace | +0.004 | [+0.001, +0.007] | 0.0674 | 0.4721 | no |
| ISOLET | CosFace | +0.005 | [+0.000, +0.009] | 0.1539 | 0.6298 | no |
| ISOLET | CE-MLP (norm.) | -0.003 | [-0.006, -0.001] | 0.0705 | 0.4721 | no |
| ISOLET | Sup-UMAP (tuned) | +0.096 | [+0.087, +0.104] | 0.0000 | 0.0005 | yes |
| ISOLET | Sup-UMAP (tuned, 16-D) | +0.086 | [+0.076, +0.095] | 0.0001 | 0.0011 | yes |
| ISOLET | Sup-UMAP (default) | +0.101 | [+0.088, +0.111] | 0.0001 | 0.0011 | yes |
| ISOLET | LDA | +0.044 | [+0.036, +0.052] | 0.0007 | 0.0059 | yes |
| ISOLET | PCA | +0.187 | [+0.178, +0.195] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | DACHP (ours) | +0.027 | [-0.005, +0.052] | 0.1894 | 1.0000 | no |
| Olivetti Faces | SupCon (same enc.) | -0.008 | [-0.018, +0.002] | 0.3046 | 1.0000 | no |
| Olivetti Faces | Triplet (batch-hard) | -0.013 | [-0.030, +0.010] | 0.3262 | 1.0000 | no |
| Olivetti Faces | Proxy-Anchor | +0.007 | [-0.010, +0.025] | 0.5012 | 1.0000 | no |
| Olivetti Faces | ArcFace | +0.025 | [-0.005, +0.057] | 0.2488 | 1.0000 | no |
| Olivetti Faces | CosFace | +0.002 | [-0.013, +0.018] | 0.7990 | 1.0000 | no |
| Olivetti Faces | CE-MLP (norm.) | +0.015 | [-0.005, +0.033] | 0.2606 | 1.0000 | no |
| Olivetti Faces | Sup-UMAP (tuned) | +0.270 | [+0.233, +0.307] | 0.0003 | 0.0034 | yes |
| Olivetti Faces | Sup-UMAP (tuned, 16-D) | +0.258 | [+0.210, +0.302] | 0.0006 | 0.0065 | yes |
| Olivetti Faces | Sup-UMAP (default) | +0.420 | [+0.355, +0.478] | 0.0003 | 0.0034 | yes |
| Olivetti Faces | LDA | +0.013 | [-0.007, +0.030] | 0.2980 | 1.0000 | no |
| Olivetti Faces | PCA | +0.240 | [+0.170, +0.300] | 0.0030 | 0.0272 | yes |
