Average rank on Test Silhouette (native dim.) (1 = best).

| Method | Average rank |
|---|---|
| DACHP-v2 (ours) | 1.55 |
| DACHP (ours) | 3.18 |
| SupCon (same enc.) | 3.91 |
| Proxy-Anchor | 3.91 |
| Triplet (batch-hard) | 6.27 |
| CosFace | 6.36 |
| Sup-UMAP (tuned, 16-D) | 7.27 |
| ArcFace | 7.64 |
| CE-MLP (norm.) | 8.55 |
| Sup-UMAP (default) | 9.68 |
| Sup-UMAP (tuned) | 9.77 |
| LDA | 10.36 |
| PCA | 12.55 |
