Average rank on Test linear-probe accuracy (1 = best).

| Method | Average rank |
|---|---|
| Proxy-Anchor | 2.55 |
| SupCon (same enc.) | 3.14 |
| CE-MLP (norm.) | 3.27 |
| Triplet (batch-hard) | 4.5 |
| DACHP-v2 (ours) | 5.27 |
| CosFace | 5.41 |
| DACHP (ours) | 5.64 |
| ArcFace | 6.73 |
| Sup-UMAP (tuned, 16-D) | 9.73 |
| LDA | 9.95 |
| Sup-UMAP (tuned) | 11.45 |
| Sup-UMAP (default) | 11.64 |
| PCA | 11.73 |
