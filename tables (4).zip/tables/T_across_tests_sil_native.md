Across-dataset comparison on Test Silhouette (native dim.) (one mean per dataset, n=11). Friedman χ²=90.09, p=4.7e-14; Nemenyi CD(α=0.05)=5.50. Wilcoxon two-sided (focal: DACHP-v2 (ours)) with Holm correction over 12 comparisons. NB: with n=11 the smallest attainable two-sided Wilcoxon p is 0.0010.

| DACHP-v2 (ours) vs | Mean Δ | 95% boot CI | W/T/L | Wilcoxon W | p | p Holm | Rank-biserial r | Avg. rank gap | > CD? |
|---|---|---|---|---|---|---|---|---|---|
| DACHP (ours) | +0.029 | [+0.016, +0.043] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +1.64 | no |
| SupCon (same enc.) | +0.054 | [+0.029, +0.080] | 10/0/1 | 4.0 | 0.0068 | 0.0137 | +0.88 | +2.36 | no |
| Triplet (batch-hard) | +0.163 | [+0.094, +0.235] | 10/0/1 | 1.0 | 0.0020 | 0.0117 | +0.97 | +4.73 | no |
| Proxy-Anchor | +0.058 | [+0.023, +0.096] | 9/0/2 | 8.0 | 0.0244 | 0.0244 | +0.76 | +2.36 | no |
| ArcFace | +0.169 | [+0.126, +0.208] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +6.09 | yes |
| CosFace | +0.134 | [+0.098, +0.168] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +4.82 | no |
| CE-MLP (norm.) | +0.202 | [+0.150, +0.258] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +7.00 | yes |
| Sup-UMAP (tuned) | +0.307 | [+0.205, +0.417] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +8.23 | yes |
| Sup-UMAP (tuned, 16-D) | +0.202 | [+0.114, +0.298] | 10/0/1 | 2.0 | 0.0029 | 0.0117 | +0.94 | +5.73 | yes |
| Sup-UMAP (default) | +0.279 | [+0.189, +0.379] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +8.14 | yes |
| LDA | +0.359 | [+0.252, +0.461] | 10/0/1 | 1.0 | 0.0020 | 0.0117 | +0.97 | +8.82 | yes |
| PCA | +0.607 | [+0.480, +0.710] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +11.00 | yes |
