Average rank on Test Silhouette (2-D) (1 = best).

| Method | Average rank |
|---|---|
| DACHP (ours) | 3.18 |
| DACHP-v2 (ours) | 3.18 |
| SupCon (same enc.) | 4.82 |
| Sup-UMAP (default) | 5.14 |
| Sup-UMAP (tuned) | 5.59 |
| Sup-UMAP (tuned, 16-D) | 6.55 |
| Triplet (batch-hard) | 7.0 |
| Proxy-Anchor | 7.45 |
| CE-MLP (norm.) | 8.18 |
| CosFace | 8.45 |
| ArcFace | 8.64 |
| LDA | 9.91 |
| PCA | 12.91 |
