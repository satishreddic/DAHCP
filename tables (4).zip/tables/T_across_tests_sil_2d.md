Across-dataset comparison on Test Silhouette (2-D) (one mean per dataset, n=11). Friedman χ²=64.83, p=2.9e-09; Nemenyi CD(α=0.05)=5.50. Wilcoxon two-sided (focal: DACHP-v2 (ours)) with Holm correction over 12 comparisons. NB: with n=11 the smallest attainable two-sided Wilcoxon p is 0.0010.

| DACHP-v2 (ours) vs | Mean Δ | 95% boot CI | W/T/L | Wilcoxon W | p | p Holm | Rank-biserial r | Avg. rank gap | > CD? |
|---|---|---|---|---|---|---|---|---|---|
| DACHP (ours) | -0.008 | [-0.047, +0.025] | 6/0/5 | 31.0 | 0.8984 | 1.0000 | +0.06 | +0.00 | no |
| SupCon (same enc.) | +0.072 | [+0.008, +0.136] | 9/0/2 | 15.0 | 0.1230 | 0.6152 | +0.55 | +1.64 | no |
| Triplet (batch-hard) | +0.184 | [+0.082, +0.276] | 9/0/2 | 5.0 | 0.0098 | 0.0586 | +0.85 | +3.82 | no |
| Proxy-Anchor | +0.195 | [+0.096, +0.306] | 10/0/1 | 2.0 | 0.0029 | 0.0264 | +0.94 | +4.27 | no |
| ArcFace | +0.247 | [+0.150, +0.346] | 10/0/1 | 1.0 | 0.0020 | 0.0215 | +0.97 | +5.45 | no |
| CosFace | +0.217 | [+0.128, +0.306] | 10/0/1 | 2.0 | 0.0029 | 0.0264 | +0.94 | +5.27 | no |
| CE-MLP (norm.) | +0.206 | [+0.131, +0.279] | 10/0/1 | 1.0 | 0.0020 | 0.0215 | +0.97 | +5.00 | no |
| Sup-UMAP (tuned) | +0.087 | [-0.049, +0.239] | 7/0/4 | 23.0 | 0.4131 | 1.0000 | +0.30 | +2.41 | no |
| Sup-UMAP (tuned, 16-D) | +0.116 | [+0.001, +0.257] | 8/0/3 | 16.0 | 0.1475 | 0.6152 | +0.52 | +3.36 | no |
| Sup-UMAP (default) | +0.058 | [-0.058, +0.194] | 8/0/3 | 22.0 | 0.3652 | 1.0000 | +0.33 | +1.95 | no |
| LDA | +0.371 | [+0.217, +0.512] | 10/0/1 | 2.0 | 0.0029 | 0.0264 | +0.94 | +6.73 | yes |
| PCA | +0.536 | [+0.395, +0.676] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +9.73 | yes |
