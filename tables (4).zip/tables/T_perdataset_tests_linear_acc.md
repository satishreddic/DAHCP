Per-dataset paired comparison of DACHP-v2 (ours) vs each method on Test linear-probe accuracy over the 5 held-out splits; Holm correction across methods within each dataset.

| Dataset | vs | Mean Δ | 95% boot CI | p (paired t) | p Holm | Sig. |
|---|---|---|---|---|---|---|
| Breast Cancer | DACHP (ours) | +0.005 | [+0.002, +0.009] | 0.0705 | 0.5040 | no |
| Breast Cancer | SupCon (same enc.) | +0.005 | [+0.000, +0.012] | 0.2080 | 0.5040 | no |
| Breast Cancer | Triplet (batch-hard) | +0.009 | [+0.004, +0.014] | 0.0341 | 0.3595 | no |
| Breast Cancer | Proxy-Anchor | +0.004 | [+0.000, +0.007] | 0.1778 | 0.5040 | no |
| Breast Cancer | ArcFace | +0.007 | [+0.002, +0.012] | 0.0993 | 0.5040 | no |
| Breast Cancer | CosFace | +0.011 | [+0.005, +0.016] | 0.0327 | 0.3595 | no |
| Breast Cancer | CE-MLP (norm.) | +0.011 | [+0.004, +0.019] | 0.0705 | 0.5040 | no |
| Breast Cancer | Sup-UMAP (tuned) | +0.014 | [+0.005, +0.023] | 0.0560 | 0.5040 | no |
| Breast Cancer | Sup-UMAP (tuned, 16-D) | +0.014 | [+0.005, +0.023] | 0.0560 | 0.5040 | no |
| Breast Cancer | Sup-UMAP (default) | +0.023 | [+0.007, +0.039] | 0.0650 | 0.5040 | no |
| Breast Cancer | LDA | +0.023 | [+0.014, +0.030] | 0.0070 | 0.0838 | no |
| Breast Cancer | PCA | +0.012 | [-0.000, +0.025] | 0.1599 | 0.5040 | no |
| Digits | DACHP (ours) | +0.004 | [-0.004, +0.015] | 0.5254 | 1.0000 | no |
| Digits | SupCon (same enc.) | -0.007 | [-0.012, -0.002] | 0.0650 | 0.3899 | no |
| Digits | Triplet (batch-hard) | -0.002 | [-0.007, +0.003] | 0.6072 | 1.0000 | no |
| Digits | Proxy-Anchor | -0.009 | [-0.012, -0.006] | 0.0074 | 0.0668 | no |
| Digits | ArcFace | +0.003 | [-0.004, +0.010] | 0.5457 | 1.0000 | no |
| Digits | CosFace | +0.001 | [-0.006, +0.007] | 0.8928 | 1.0000 | no |
| Digits | CE-MLP (norm.) | -0.009 | [-0.013, -0.005] | 0.0205 | 0.1433 | no |
| Digits | Sup-UMAP (tuned) | +0.023 | [+0.013, +0.032] | 0.0118 | 0.0942 | no |
| Digits | Sup-UMAP (tuned, 16-D) | +0.003 | [-0.002, +0.008] | 0.4130 | 1.0000 | no |
| Digits | Sup-UMAP (default) | +0.039 | [+0.031, +0.047] | 0.0012 | 0.0136 | yes |
| Digits | LDA | +0.026 | [+0.018, +0.033] | 0.0042 | 0.0416 | yes |
| Digits | PCA | +0.043 | [+0.040, +0.047] | 0.0000 | 0.0003 | yes |
| Mice Protein | DACHP (ours) | +0.012 | [-0.005, +0.031] | 0.3127 | 1.0000 | no |
| Mice Protein | SupCon (same enc.) | +0.018 | [-0.002, +0.038] | 0.2137 | 1.0000 | no |
| Mice Protein | Triplet (batch-hard) | +0.013 | [-0.038, +0.080] | 0.7297 | 1.0000 | no |
| Mice Protein | Proxy-Anchor | -0.018 | [-0.052, +0.015] | 0.3979 | 1.0000 | no |
| Mice Protein | ArcFace | +0.029 | [+0.001, +0.061] | 0.1554 | 0.9344 | no |
| Mice Protein | CosFace | +0.029 | [+0.004, +0.060] | 0.1335 | 0.9344 | no |
| Mice Protein | CE-MLP (norm.) | +0.048 | [+0.020, +0.077] | 0.0434 | 0.3470 | no |
| Mice Protein | Sup-UMAP (tuned) | +0.271 | [+0.259, +0.283] | 0.0000 | 0.0000 | yes |
| Mice Protein | Sup-UMAP (tuned, 16-D) | +0.246 | [+0.231, +0.262] | 0.0000 | 0.0001 | yes |
| Mice Protein | Sup-UMAP (default) | +0.274 | [+0.253, +0.295] | 0.0000 | 0.0003 | yes |
| Mice Protein | LDA | +0.025 | [-0.024, +0.080] | 0.4693 | 1.0000 | no |
| Mice Protein | PCA | +0.080 | [+0.050, +0.111] | 0.0118 | 0.1061 | no |
| Annealing | DACHP (ours) | -0.001 | [-0.011, +0.008] | 0.8466 | 1.0000 | no |
| Annealing | SupCon (same enc.) | -0.006 | [-0.012, +0.001] | 0.2302 | 1.0000 | no |
| Annealing | Triplet (batch-hard) | -0.001 | [-0.008, +0.008] | 0.8276 | 1.0000 | no |
| Annealing | Proxy-Anchor | -0.007 | [-0.010, -0.003] | 0.0327 | 0.2941 | no |
| Annealing | ArcFace | -0.003 | [-0.008, +0.002] | 0.3046 | 1.0000 | no |
| Annealing | CosFace | -0.004 | [-0.011, +0.002] | 0.2943 | 1.0000 | no |
| Annealing | CE-MLP (norm.) | -0.009 | [-0.016, -0.001] | 0.0993 | 0.5958 | no |
| Annealing | Sup-UMAP (tuned) | +0.056 | [+0.022, +0.098] | 0.0573 | 0.4585 | no |
| Annealing | Sup-UMAP (tuned, 16-D) | +0.040 | [+0.029, +0.051] | 0.0039 | 0.0427 | yes |
| Annealing | Sup-UMAP (default) | +0.077 | [+0.050, +0.104] | 0.0081 | 0.0806 | no |
| Annealing | LDA | +0.018 | [+0.006, +0.030] | 0.0669 | 0.4680 | no |
| Annealing | PCA | +0.086 | [+0.077, +0.096] | 0.0001 | 0.0014 | yes |
| COIL-20 | DACHP (ours) | +0.002 | [-0.003, +0.007] | 0.5012 | 1.0000 | no |
| COIL-20 | SupCon (same enc.) | -0.001 | [-0.004, +0.003] | 0.7489 | 1.0000 | no |
| COIL-20 | Triplet (batch-hard) | -0.001 | [-0.005, +0.003] | 0.5870 | 1.0000 | no |
| COIL-20 | Proxy-Anchor | -0.003 | [-0.006, +0.001] | 0.1778 | 1.0000 | no |
| COIL-20 | ArcFace | +0.001 | [-0.003, +0.004] | 0.7489 | 1.0000 | no |
| COIL-20 | CosFace | -0.003 | [-0.008, +0.002] | 0.3739 | 1.0000 | no |
| COIL-20 | CE-MLP (norm.) | -0.001 | [-0.006, +0.003] | 0.6702 | 1.0000 | no |
| COIL-20 | Sup-UMAP (tuned) | +0.366 | [+0.294, +0.452] | 0.0015 | 0.0160 | yes |
| COIL-20 | Sup-UMAP (tuned, 16-D) | +0.031 | [+0.022, +0.040] | 0.0040 | 0.0364 | yes |
| COIL-20 | Sup-UMAP (default) | +0.077 | [+0.056, +0.103] | 0.0054 | 0.0429 | yes |
| COIL-20 | LDA | +0.121 | [+0.096, +0.142] | 0.0009 | 0.0102 | yes |
| COIL-20 | PCA | +0.021 | [+0.015, +0.024] | 0.0015 | 0.0160 | yes |
| CNAE-9 | DACHP (ours) | +0.006 | [+0.001, +0.010] | 0.1087 | 0.5435 | no |
| CNAE-9 | SupCon (same enc.) | -0.008 | [-0.023, +0.001] | 0.3219 | 1.0000 | no |
| CNAE-9 | Triplet (batch-hard) | -0.011 | [-0.016, -0.006] | 0.0161 | 0.0968 | no |
| CNAE-9 | Proxy-Anchor | -0.008 | [-0.011, -0.006] | 0.0086 | 0.0686 | no |
| CNAE-9 | ArcFace | +0.001 | [-0.009, +0.010] | 0.8757 | 1.0000 | no |
| CNAE-9 | CosFace | +0.003 | [-0.006, +0.011] | 0.6213 | 1.0000 | no |
| CNAE-9 | CE-MLP (norm.) | -0.003 | [-0.010, +0.005] | 0.5529 | 1.0000 | no |
| CNAE-9 | Sup-UMAP (tuned) | +0.094 | [+0.076, +0.120] | 0.0021 | 0.0229 | yes |
| CNAE-9 | Sup-UMAP (tuned, 16-D) | +0.045 | [+0.030, +0.066] | 0.0120 | 0.0841 | no |
| CNAE-9 | Sup-UMAP (default) | +0.084 | [+0.072, +0.101] | 0.0006 | 0.0069 | yes |
| CNAE-9 | LDA | +0.085 | [+0.064, +0.108] | 0.0022 | 0.0229 | yes |
| CNAE-9 | PCA | +0.097 | [+0.075, +0.127] | 0.0030 | 0.0272 | yes |
| MNIST | DACHP (ours) | +0.002 | [-0.001, +0.005] | 0.2997 | 0.5444 | no |
| MNIST | SupCon (same enc.) | -0.004 | [-0.005, -0.002] | 0.0178 | 0.0891 | no |
| MNIST | Triplet (batch-hard) | -0.004 | [-0.007, -0.001] | 0.0595 | 0.1784 | no |
| MNIST | Proxy-Anchor | -0.006 | [-0.009, -0.005] | 0.0116 | 0.0698 | no |
| MNIST | ArcFace | -0.002 | [-0.003, -0.001] | 0.0088 | 0.0614 | no |
| MNIST | CosFace | -0.002 | [-0.005, +0.001] | 0.2722 | 0.5444 | no |
| MNIST | CE-MLP (norm.) | -0.008 | [-0.012, -0.003] | 0.0333 | 0.1333 | no |
| MNIST | Sup-UMAP (tuned) | +0.038 | [+0.035, +0.041] | 0.0000 | 0.0003 | yes |
| MNIST | Sup-UMAP (tuned, 16-D) | +0.031 | [+0.028, +0.035] | 0.0001 | 0.0007 | yes |
| MNIST | Sup-UMAP (default) | +0.038 | [+0.035, +0.041] | 0.0000 | 0.0003 | yes |
| MNIST | LDA | +0.092 | [+0.088, +0.096] | 0.0000 | 0.0000 | yes |
| MNIST | PCA | +0.100 | [+0.099, +0.101] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | DACHP (ours) | -0.003 | [-0.006, -0.001] | 0.0845 | 0.3381 | no |
| Fashion-MNIST | SupCon (same enc.) | -0.006 | [-0.007, -0.005] | 0.0010 | 0.0069 | yes |
| Fashion-MNIST | Triplet (batch-hard) | +0.024 | [+0.016, +0.032] | 0.0067 | 0.0401 | yes |
| Fashion-MNIST | Proxy-Anchor | -0.001 | [-0.003, +0.001] | 0.4565 | 0.8134 | no |
| Fashion-MNIST | ArcFace | +0.003 | [+0.000, +0.005] | 0.1299 | 0.3898 | no |
| Fashion-MNIST | CosFace | -0.001 | [-0.003, +0.001] | 0.4067 | 0.8134 | no |
| Fashion-MNIST | CE-MLP (norm.) | -0.009 | [-0.014, -0.006] | 0.0170 | 0.0852 | no |
| Fashion-MNIST | Sup-UMAP (tuned) | +0.062 | [+0.053, +0.069] | 0.0002 | 0.0015 | yes |
| Fashion-MNIST | Sup-UMAP (tuned, 16-D) | +0.050 | [+0.047, +0.052] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | Sup-UMAP (default) | +0.058 | [+0.053, +0.062] | 0.0000 | 0.0004 | yes |
| Fashion-MNIST | LDA | +0.054 | [+0.050, +0.060] | 0.0000 | 0.0004 | yes |
| Fashion-MNIST | PCA | +0.087 | [+0.080, +0.093] | 0.0000 | 0.0003 | yes |
| HAR | DACHP (ours) | -0.001 | [-0.002, -0.001] | 0.0109 | 0.0654 | no |
| HAR | SupCon (same enc.) | -0.001 | [-0.002, +0.001] | 0.3262 | 1.0000 | no |
| HAR | Triplet (batch-hard) | +0.000 | [-0.002, +0.002] | 0.9226 | 1.0000 | no |
| HAR | Proxy-Anchor | -0.002 | [-0.002, -0.001] | 0.0029 | 0.0200 | yes |
| HAR | ArcFace | -0.000 | [-0.001, +0.001] | 0.5870 | 1.0000 | no |
| HAR | CosFace | -0.000 | [-0.002, +0.001] | 0.6541 | 1.0000 | no |
| HAR | CE-MLP (norm.) | -0.002 | [-0.004, -0.001] | 0.0478 | 0.2390 | no |
| HAR | Sup-UMAP (tuned) | +0.037 | [+0.036, +0.040] | 0.0000 | 0.0001 | yes |
| HAR | Sup-UMAP (tuned, 16-D) | +0.037 | [+0.036, +0.038] | 0.0000 | 0.0000 | yes |
| HAR | Sup-UMAP (default) | +0.060 | [+0.056, +0.065] | 0.0000 | 0.0002 | yes |
| HAR | LDA | +0.008 | [+0.006, +0.009] | 0.0004 | 0.0036 | yes |
| HAR | PCA | +0.093 | [+0.090, +0.097] | 0.0000 | 0.0000 | yes |
| ISOLET | DACHP (ours) | -0.001 | [-0.002, +0.000] | 0.2835 | 0.8505 | no |
| ISOLET | SupCon (same enc.) | -0.003 | [-0.005, -0.002] | 0.0262 | 0.1836 | no |
| ISOLET | Triplet (batch-hard) | -0.001 | [-0.003, +0.001] | 0.5473 | 1.0000 | no |
| ISOLET | Proxy-Anchor | +0.001 | [-0.003, +0.003] | 0.6957 | 1.0000 | no |
| ISOLET | ArcFace | +0.005 | [-0.000, +0.008] | 0.1250 | 0.7502 | no |
| ISOLET | CosFace | +0.004 | [-0.000, +0.009] | 0.1808 | 0.8458 | no |
| ISOLET | CE-MLP (norm.) | -0.003 | [-0.005, +0.000] | 0.1692 | 0.8458 | no |
| ISOLET | Sup-UMAP (tuned) | +0.106 | [+0.091, +0.122] | 0.0003 | 0.0023 | yes |
| ISOLET | Sup-UMAP (tuned, 16-D) | +0.087 | [+0.077, +0.096] | 0.0001 | 0.0008 | yes |
| ISOLET | Sup-UMAP (default) | +0.104 | [+0.098, +0.110] | 0.0000 | 0.0001 | yes |
| ISOLET | LDA | +0.050 | [+0.046, +0.056] | 0.0001 | 0.0005 | yes |
| ISOLET | PCA | +0.112 | [+0.108, +0.117] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | DACHP (ours) | +0.017 | [-0.018, +0.037] | 0.3627 | 1.0000 | no |
| Olivetti Faces | SupCon (same enc.) | -0.015 | [-0.030, +0.002] | 0.1778 | 1.0000 | no |
| Olivetti Faces | Triplet (batch-hard) | -0.013 | [-0.030, +0.010] | 0.3262 | 1.0000 | no |
| Olivetti Faces | Proxy-Anchor | -0.005 | [-0.023, +0.013] | 0.6483 | 1.0000 | no |
| Olivetti Faces | ArcFace | +0.020 | [-0.020, +0.062] | 0.4442 | 1.0000 | no |
| Olivetti Faces | CosFace | -0.003 | [-0.023, +0.018] | 0.8379 | 1.0000 | no |
| Olivetti Faces | CE-MLP (norm.) | -0.002 | [-0.010, +0.005] | 0.6213 | 1.0000 | no |
| Olivetti Faces | Sup-UMAP (tuned) | +0.520 | [+0.472, +0.565] | 0.0000 | 0.0005 | yes |
| Olivetti Faces | Sup-UMAP (tuned, 16-D) | +0.255 | [+0.225, +0.285] | 0.0001 | 0.0012 | yes |
| Olivetti Faces | Sup-UMAP (default) | +0.595 | [+0.543, +0.647] | 0.0000 | 0.0005 | yes |
| Olivetti Faces | LDA | +0.020 | [+0.003, +0.035] | 0.0993 | 0.7944 | no |
| Olivetti Faces | PCA | +0.047 | [+0.017, +0.077] | 0.0525 | 0.4728 | no |
