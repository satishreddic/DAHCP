Per-dataset paired comparison of DACHP-v2 (ours) vs each method on Test Silhouette (native dim.) over the 5 held-out splits; Holm correction across methods within each dataset.

| Dataset | vs | Mean Δ | 95% boot CI | p (paired t) | p Holm | Sig. |
|---|---|---|---|---|---|---|
| Breast Cancer | DACHP (ours) | +0.018 | [+0.013, +0.024] | 0.0049 | 0.0195 | yes |
| Breast Cancer | SupCon (same enc.) | +0.062 | [+0.043, +0.085] | 0.0063 | 0.0195 | yes |
| Breast Cancer | Triplet (batch-hard) | +0.064 | [+0.046, +0.086] | 0.0049 | 0.0195 | yes |
| Breast Cancer | Proxy-Anchor | +0.091 | [+0.066, +0.110] | 0.0018 | 0.0101 | yes |
| Breast Cancer | ArcFace | +0.138 | [+0.119, +0.157] | 0.0002 | 0.0025 | yes |
| Breast Cancer | CosFace | +0.105 | [+0.085, +0.124] | 0.0007 | 0.0052 | yes |
| Breast Cancer | CE-MLP (norm.) | +0.212 | [+0.187, +0.238] | 0.0001 | 0.0014 | yes |
| Breast Cancer | Sup-UMAP (tuned) | +0.140 | [+0.108, +0.172] | 0.0017 | 0.0101 | yes |
| Breast Cancer | Sup-UMAP (tuned, 16-D) | +0.128 | [+0.102, +0.154] | 0.0010 | 0.0069 | yes |
| Breast Cancer | Sup-UMAP (default) | +0.162 | [+0.097, +0.228] | 0.0118 | 0.0195 | yes |
| Breast Cancer | LDA | +0.258 | [+0.220, +0.293] | 0.0003 | 0.0025 | yes |
| Breast Cancer | PCA | +0.603 | [+0.574, +0.628] | 0.0000 | 0.0000 | yes |
| Digits | DACHP (ours) | +0.052 | [+0.044, +0.063] | 0.0008 | 0.0033 | yes |
| Digits | SupCon (same enc.) | +0.021 | [+0.014, +0.027] | 0.0065 | 0.0195 | yes |
| Digits | Triplet (batch-hard) | +0.245 | [+0.232, +0.258] | 0.0000 | 0.0000 | yes |
| Digits | Proxy-Anchor | +0.083 | [+0.075, +0.090] | 0.0000 | 0.0003 | yes |
| Digits | ArcFace | +0.206 | [+0.194, +0.216] | 0.0000 | 0.0000 | yes |
| Digits | CosFace | +0.181 | [+0.170, +0.192] | 0.0000 | 0.0001 | yes |
| Digits | CE-MLP (norm.) | +0.253 | [+0.244, +0.263] | 0.0000 | 0.0000 | yes |
| Digits | Sup-UMAP (tuned) | +0.003 | [-0.020, +0.025] | 0.8528 | 0.8528 | no |
| Digits | Sup-UMAP (tuned, 16-D) | -0.082 | [-0.092, -0.075] | 0.0001 | 0.0003 | yes |
| Digits | Sup-UMAP (default) | +0.013 | [-0.001, +0.027] | 0.1728 | 0.3456 | no |
| Digits | LDA | +0.365 | [+0.357, +0.372] | 0.0000 | 0.0000 | yes |
| Digits | PCA | +0.575 | [+0.551, +0.601] | 0.0000 | 0.0000 | yes |
| Mice Protein | DACHP (ours) | +0.020 | [-0.001, +0.043] | 0.1919 | 0.9593 | no |
| Mice Protein | SupCon (same enc.) | +0.022 | [+0.003, +0.036] | 0.0803 | 0.5619 | no |
| Mice Protein | Triplet (batch-hard) | -0.000 | [-0.020, +0.021] | 0.9711 | 1.0000 | no |
| Mice Protein | Proxy-Anchor | -0.033 | [-0.066, -0.006] | 0.1303 | 0.7818 | no |
| Mice Protein | ArcFace | +0.007 | [-0.013, +0.028] | 0.5708 | 1.0000 | no |
| Mice Protein | CosFace | +0.002 | [-0.021, +0.024] | 0.9074 | 1.0000 | no |
| Mice Protein | CE-MLP (norm.) | +0.029 | [+0.011, +0.045] | 0.0419 | 0.3355 | no |
| Mice Protein | Sup-UMAP (tuned) | +0.205 | [+0.155, +0.269] | 0.0032 | 0.0321 | yes |
| Mice Protein | Sup-UMAP (tuned, 16-D) | +0.190 | [+0.140, +0.242] | 0.0028 | 0.0312 | yes |
| Mice Protein | Sup-UMAP (default) | +0.234 | [+0.192, +0.276] | 0.0007 | 0.0079 | yes |
| Mice Protein | LDA | -0.033 | [-0.072, +0.019] | 0.2760 | 1.0000 | no |
| Mice Protein | PCA | +0.098 | [+0.067, +0.133] | 0.0072 | 0.0645 | no |
| Annealing | DACHP (ours) | +0.028 | [-0.040, +0.074] | 0.4533 | 0.4533 | no |
| Annealing | SupCon (same enc.) | +0.066 | [-0.002, +0.116] | 0.1263 | 0.2526 | no |
| Annealing | Triplet (batch-hard) | +0.312 | [+0.245, +0.366] | 0.0010 | 0.0104 | yes |
| Annealing | Proxy-Anchor | +0.161 | [+0.111, +0.196] | 0.0030 | 0.0190 | yes |
| Annealing | ArcFace | +0.129 | [+0.083, +0.157] | 0.0050 | 0.0190 | yes |
| Annealing | CosFace | +0.116 | [+0.096, +0.129] | 0.0003 | 0.0031 | yes |
| Annealing | CE-MLP (norm.) | +0.403 | [+0.285, +0.499] | 0.0034 | 0.0190 | yes |
| Annealing | Sup-UMAP (tuned) | +0.577 | [+0.415, +0.672] | 0.0020 | 0.0162 | yes |
| Annealing | Sup-UMAP (tuned, 16-D) | +0.554 | [+0.402, +0.660] | 0.0018 | 0.0162 | yes |
| Annealing | Sup-UMAP (default) | +0.573 | [+0.394, +0.681] | 0.0030 | 0.0190 | yes |
| Annealing | LDA | +0.337 | [+0.235, +0.410] | 0.0027 | 0.0190 | yes |
| Annealing | PCA | +0.689 | [+0.588, +0.766] | 0.0002 | 0.0021 | yes |
| COIL-20 | DACHP (ours) | +0.058 | [+0.049, +0.066] | 0.0003 | 0.0008 | yes |
| COIL-20 | SupCon (same enc.) | +0.018 | [+0.016, +0.019] | 0.0001 | 0.0003 | yes |
| COIL-20 | Triplet (batch-hard) | +0.064 | [+0.060, +0.068] | 0.0000 | 0.0001 | yes |
| COIL-20 | Proxy-Anchor | -0.005 | [-0.010, +0.000] | 0.2140 | 0.2140 | no |
| COIL-20 | ArcFace | +0.164 | [+0.157, +0.175] | 0.0000 | 0.0001 | yes |
| COIL-20 | CosFace | +0.117 | [+0.110, +0.125] | 0.0000 | 0.0001 | yes |
| COIL-20 | CE-MLP (norm.) | +0.137 | [+0.128, +0.148] | 0.0000 | 0.0001 | yes |
| COIL-20 | Sup-UMAP (tuned) | +0.639 | [+0.585, +0.693] | 0.0000 | 0.0002 | yes |
| COIL-20 | Sup-UMAP (tuned, 16-D) | +0.250 | [+0.234, +0.260] | 0.0000 | 0.0000 | yes |
| COIL-20 | Sup-UMAP (default) | +0.233 | [+0.200, +0.275] | 0.0004 | 0.0008 | yes |
| COIL-20 | LDA | +0.498 | [+0.488, +0.508] | 0.0000 | 0.0000 | yes |
| COIL-20 | PCA | +0.624 | [+0.607, +0.639] | 0.0000 | 0.0000 | yes |
| CNAE-9 | DACHP (ours) | +0.014 | [+0.007, +0.024] | 0.0426 | 0.0426 | yes |
| CNAE-9 | SupCon (same enc.) | +0.099 | [+0.091, +0.104] | 0.0000 | 0.0001 | yes |
| CNAE-9 | Triplet (batch-hard) | +0.145 | [+0.132, +0.160] | 0.0001 | 0.0004 | yes |
| CNAE-9 | Proxy-Anchor | +0.032 | [+0.024, +0.042] | 0.0029 | 0.0086 | yes |
| CNAE-9 | ArcFace | +0.161 | [+0.146, +0.175] | 0.0000 | 0.0003 | yes |
| CNAE-9 | CosFace | +0.147 | [+0.131, +0.161] | 0.0001 | 0.0004 | yes |
| CNAE-9 | CE-MLP (norm.) | +0.242 | [+0.228, +0.257] | 0.0000 | 0.0001 | yes |
| CNAE-9 | Sup-UMAP (tuned) | +0.222 | [+0.170, +0.277] | 0.0020 | 0.0079 | yes |
| CNAE-9 | Sup-UMAP (tuned, 16-D) | +0.070 | [+0.051, +0.092] | 0.0047 | 0.0093 | yes |
| CNAE-9 | Sup-UMAP (default) | +0.192 | [+0.172, +0.220] | 0.0002 | 0.0008 | yes |
| CNAE-9 | LDA | +0.391 | [+0.366, +0.410] | 0.0000 | 0.0001 | yes |
| CNAE-9 | PCA | +0.651 | [+0.619, +0.681] | 0.0000 | 0.0000 | yes |
| MNIST | DACHP (ours) | +0.039 | [+0.029, +0.048] | 0.0021 | 0.0021 | yes |
| MNIST | SupCon (same enc.) | +0.113 | [+0.101, +0.124] | 0.0001 | 0.0002 | yes |
| MNIST | Triplet (batch-hard) | +0.185 | [+0.171, +0.199] | 0.0000 | 0.0001 | yes |
| MNIST | Proxy-Anchor | +0.174 | [+0.160, +0.187] | 0.0000 | 0.0001 | yes |
| MNIST | ArcFace | +0.218 | [+0.207, +0.228] | 0.0000 | 0.0000 | yes |
| MNIST | CosFace | +0.246 | [+0.237, +0.254] | 0.0000 | 0.0000 | yes |
| MNIST | CE-MLP (norm.) | +0.243 | [+0.229, +0.257] | 0.0000 | 0.0000 | yes |
| MNIST | Sup-UMAP (tuned) | +0.218 | [+0.208, +0.227] | 0.0000 | 0.0000 | yes |
| MNIST | Sup-UMAP (tuned, 16-D) | +0.119 | [+0.107, +0.132] | 0.0001 | 0.0002 | yes |
| MNIST | Sup-UMAP (default) | +0.218 | [+0.208, +0.227] | 0.0000 | 0.0000 | yes |
| MNIST | LDA | +0.655 | [+0.607, +0.698] | 0.0000 | 0.0001 | yes |
| MNIST | PCA | +0.769 | [+0.745, +0.787] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | DACHP (ours) | +0.001 | [-0.002, +0.004] | 0.6141 | 0.6141 | no |
| Fashion-MNIST | SupCon (same enc.) | +0.055 | [+0.051, +0.059] | 0.0000 | 0.0001 | yes |
| Fashion-MNIST | Triplet (batch-hard) | +0.369 | [+0.338, +0.400] | 0.0000 | 0.0001 | yes |
| Fashion-MNIST | Proxy-Anchor | +0.026 | [+0.021, +0.030] | 0.0006 | 0.0012 | yes |
| Fashion-MNIST | ArcFace | +0.207 | [+0.194, +0.220] | 0.0000 | 0.0001 | yes |
| Fashion-MNIST | CosFace | +0.162 | [+0.153, +0.170] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | CE-MLP (norm.) | +0.129 | [+0.123, +0.135] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | Sup-UMAP (tuned) | +0.317 | [+0.299, +0.333] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | Sup-UMAP (tuned, 16-D) | +0.220 | [+0.210, +0.231] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | Sup-UMAP (default) | +0.247 | [+0.231, +0.263] | 0.0000 | 0.0001 | yes |
| Fashion-MNIST | LDA | +0.373 | [+0.368, +0.377] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | PCA | +0.550 | [+0.540, +0.558] | 0.0000 | 0.0000 | yes |
| HAR | DACHP (ours) | +0.003 | [+0.000, +0.006] | 0.1124 | 0.1124 | no |
| HAR | SupCon (same enc.) | +0.043 | [+0.040, +0.047] | 0.0000 | 0.0002 | yes |
| HAR | Triplet (batch-hard) | +0.119 | [+0.109, +0.134] | 0.0001 | 0.0003 | yes |
| HAR | Proxy-Anchor | +0.004 | [+0.003, +0.005] | 0.0012 | 0.0023 | yes |
| HAR | ArcFace | +0.278 | [+0.270, +0.284] | 0.0000 | 0.0000 | yes |
| HAR | CosFace | +0.160 | [+0.154, +0.166] | 0.0000 | 0.0000 | yes |
| HAR | CE-MLP (norm.) | +0.238 | [+0.227, +0.250] | 0.0000 | 0.0000 | yes |
| HAR | Sup-UMAP (tuned) | +0.241 | [+0.216, +0.267] | 0.0001 | 0.0003 | yes |
| HAR | Sup-UMAP (tuned, 16-D) | +0.185 | [+0.178, +0.192] | 0.0000 | 0.0000 | yes |
| HAR | Sup-UMAP (default) | +0.282 | [+0.262, +0.310] | 0.0000 | 0.0002 | yes |
| HAR | LDA | +0.324 | [+0.320, +0.328] | 0.0000 | 0.0000 | yes |
| HAR | PCA | +0.869 | [+0.856, +0.880] | 0.0000 | 0.0000 | yes |
| ISOLET | DACHP (ours) | +0.009 | [+0.003, +0.015] | 0.0530 | 0.0530 | no |
| ISOLET | SupCon (same enc.) | +0.128 | [+0.123, +0.133] | 0.0000 | 0.0000 | yes |
| ISOLET | Triplet (batch-hard) | +0.290 | [+0.284, +0.297] | 0.0000 | 0.0000 | yes |
| ISOLET | Proxy-Anchor | +0.022 | [+0.018, +0.027] | 0.0015 | 0.0030 | yes |
| ISOLET | ArcFace | +0.237 | [+0.232, +0.243] | 0.0000 | 0.0000 | yes |
| ISOLET | CosFace | +0.165 | [+0.159, +0.171] | 0.0000 | 0.0000 | yes |
| ISOLET | CE-MLP (norm.) | +0.153 | [+0.149, +0.158] | 0.0000 | 0.0000 | yes |
| ISOLET | Sup-UMAP (tuned) | +0.408 | [+0.391, +0.425] | 0.0000 | 0.0000 | yes |
| ISOLET | Sup-UMAP (tuned, 16-D) | +0.276 | [+0.251, +0.297] | 0.0000 | 0.0001 | yes |
| ISOLET | Sup-UMAP (default) | +0.332 | [+0.310, +0.354] | 0.0000 | 0.0000 | yes |
| ISOLET | LDA | +0.568 | [+0.560, +0.575] | 0.0000 | 0.0000 | yes |
| ISOLET | PCA | +0.780 | [+0.772, +0.787] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | DACHP (ours) | +0.076 | [+0.060, +0.091] | 0.0013 | 0.0079 | yes |
| Olivetti Faces | SupCon (same enc.) | -0.027 | [-0.037, -0.019] | 0.0062 | 0.0250 | yes |
| Olivetti Faces | Triplet (batch-hard) | +0.005 | [-0.016, +0.029] | 0.7018 | 0.7018 | no |
| Olivetti Faces | Proxy-Anchor | +0.080 | [+0.056, +0.099] | 0.0028 | 0.0142 | yes |
| Olivetti Faces | ArcFace | +0.109 | [+0.082, +0.152] | 0.0063 | 0.0250 | yes |
| Olivetti Faces | CosFace | +0.077 | [+0.050, +0.111] | 0.0123 | 0.0250 | yes |
| Olivetti Faces | CE-MLP (norm.) | +0.186 | [+0.152, +0.217] | 0.0005 | 0.0046 | yes |
| Olivetti Faces | Sup-UMAP (tuned) | +0.410 | [+0.333, +0.487] | 0.0008 | 0.0067 | yes |
| Olivetti Faces | Sup-UMAP (tuned, 16-D) | +0.317 | [+0.253, +0.382] | 0.0011 | 0.0079 | yes |
| Olivetti Faces | Sup-UMAP (default) | +0.580 | [+0.525, +0.644] | 0.0001 | 0.0008 | yes |
| Olivetti Faces | LDA | +0.215 | [+0.192, +0.238] | 0.0001 | 0.0008 | yes |
| Olivetti Faces | PCA | +0.469 | [+0.435, +0.502] | 0.0000 | 0.0002 | yes |
