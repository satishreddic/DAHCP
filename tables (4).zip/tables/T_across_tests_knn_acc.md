Across-dataset comparison on Test 5-NN accuracy (one mean per dataset, n=11). Friedman χ²=95.45, p=4.3e-15; Nemenyi CD(α=0.05)=5.50. Wilcoxon two-sided (focal: DACHP-v2 (ours)) with Holm correction over 12 comparisons. NB: with n=11 the smallest attainable two-sided Wilcoxon p is 0.0010.

| DACHP-v2 (ours) vs | Mean Δ | 95% boot CI | W/T/L | Wilcoxon W | p | p Holm | Rank-biserial r | Avg. rank gap | > CD? |
|---|---|---|---|---|---|---|---|---|---|
| DACHP (ours) | +0.007 | [+0.001, +0.015] | 8/0/3 | 13.0 | 0.0830 | 0.3711 | +0.61 | +1.32 | no |
| SupCon (same enc.) | -0.004 | [-0.007, -0.002] | 1/0/10 | 6.0 | 0.0137 | 0.1094 | -0.82 | -1.86 | no |
| Triplet (batch-hard) | +0.001 | [-0.004, +0.007] | 5/0/6 | 31.0 | 0.8984 | 1.0000 | +0.06 | -0.27 | no |
| Proxy-Anchor | -0.004 | [-0.007, -0.000] | 3/0/8 | 11.0 | 0.0537 | 0.3223 | -0.67 | -2.45 | no |
| ArcFace | +0.007 | [+0.001, +0.016] | 7/1/3 | 12.5 | 0.0742 | 0.3711 | +0.67 | +1.32 | no |
| CosFace | +0.003 | [-0.001, +0.010] | 5/0/6 | 25.0 | 0.5195 | 1.0000 | +0.24 | +0.00 | no |
| CE-MLP (norm.) | +0.002 | [-0.005, +0.012] | 3/0/8 | 22.0 | 0.3652 | 1.0000 | -0.33 | -2.00 | no |
| Sup-UMAP (tuned) | +0.084 | [+0.040, +0.138] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +5.50 | no |
| Sup-UMAP (tuned, 16-D) | +0.076 | [+0.032, +0.133] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +4.91 | no |
| Sup-UMAP (default) | +0.104 | [+0.049, +0.181] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +6.86 | yes |
| LDA | +0.031 | [+0.010, +0.052] | 9/1/1 | 6.5 | 0.0156 | 0.1094 | +0.82 | +4.05 | no |
| PCA | +0.096 | [+0.048, +0.149] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +6.27 | yes |
