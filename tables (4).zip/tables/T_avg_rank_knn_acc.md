Average rank on Test 5-NN accuracy (1 = best).

| Method | Average rank |
|---|---|
| Proxy-Anchor | 2.73 |
| CE-MLP (norm.) | 3.18 |
| SupCon (same enc.) | 3.32 |
| Triplet (batch-hard) | 4.91 |
| CosFace | 5.18 |
| DACHP-v2 (ours) | 5.18 |
| DACHP (ours) | 6.5 |
| ArcFace | 6.5 |
| LDA | 9.23 |
| Sup-UMAP (tuned, 16-D) | 10.09 |
| Sup-UMAP (tuned) | 10.68 |
| PCA | 11.45 |
| Sup-UMAP (default) | 12.05 |
