Wall-clock training/fitting time (mean over 5 runs) and DACHP peak memory where it was recorded. Times depend on the hardware used.

| Dataset | DACHP (ours) time (s) | DACHP peak memory (MB) | DACHP params | DACHP H1/H2 | Batch | SupCon (same enc.) time (s) | Sup-UMAP (tuned) time (s) |
|---|---|---|---|---|---|---|---|
| Breast Cancer | 1.7 | 33 | 22785 | 128/64 | 341 | 0.9 | 0.7 |
| Digits | 2.1 | 164 | 27137 | 128/64 | 1077 | 1.0 | 3.7 |
| Mice Protein | 1.7 | 71 | 38434 | 154/77 | 645 | 0.9 | 2.2 |
| Annealing | 1.8 | 56 | 23809 | 128/64 | 538 | 0.9 | 1.7 |
| COIL-20 | 1.8 | 131 | 635049 | 432/216 | 864 | 0.9 | 3.3 |
| CNAE-9 | 1.9 | 83 | 387135 | 324/162 | 648 | 1.0 | 3.2 |
| MNIST | 26.4 | 127 | 3707057 | 1568/784 | 512 | 17.4 | 16.9 |
| Fashion-MNIST | 25.8 | 127 | 3707057 | 1568/784 | 512 | 17.6 | 15.5 |
| HAR | 23.4 | 97 | 1902318 | 1122/561 | 512 | 13.4 | 17.0 |
| ISOLET | 34.7 | 97 | 2299414 | 1234/617 | 256 | 20.5 | 13.0 |
| Olivetti Faces | 1.8 | 39 | 543233 | 128/64 | 240 | 0.9 | 0.6 |
