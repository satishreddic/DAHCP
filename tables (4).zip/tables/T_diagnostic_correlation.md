Spearman correlation between input-space diagnostics and DACHP's gain over tuned Sup-UMAP (n=11 datasets; exploratory, uncorrected).

| Diagnostic | Gain | Spearman ρ | p |
|---|---|---|---|
| knn_purity | Δ kNN | -0.68 | 0.021 |
| knn_purity | Δ Sil | -0.45 | 0.160 |
| false_nn_rate | Δ kNN | +0.27 | 0.417 |
| false_nn_rate | Δ Sil | +0.17 | 0.612 |
| hub_skew | Δ kNN | +0.21 | 0.537 |
| hub_skew | Δ Sil | -0.02 | 0.958 |
| dist_cv | Δ kNN | -0.55 | 0.077 |
| dist_cv | Δ Sil | -0.55 | 0.077 |
| rel_contrast | Δ kNN | -0.71 | 0.015 |
| rel_contrast | Δ Sil | +0.10 | 0.770 |
| n_over_d | Δ kNN | -0.67 | 0.024 |
| n_over_d | Δ Sil | -0.39 | 0.233 |
