Across-dataset comparison on Test linear-probe accuracy (one mean per dataset, n=11). Friedman χ²=103.43, p=1.2e-16; Nemenyi CD(α=0.05)=5.50. Wilcoxon two-sided (focal: DACHP-v2 (ours)) with Holm correction over 12 comparisons. NB: with n=11 the smallest attainable two-sided Wilcoxon p is 0.0010.

| DACHP-v2 (ours) vs | Mean Δ | 95% boot CI | W/T/L | Wilcoxon W | p | p Holm | Rank-biserial r | Avg. rank gap | > CD? |
|---|---|---|---|---|---|---|---|---|---|
| DACHP (ours) | +0.004 | [+0.001, +0.008] | 7/0/4 | 12.0 | 0.0674 | 0.4043 | +0.64 | +0.36 | no |
| SupCon (same enc.) | -0.003 | [-0.007, +0.003] | 2/0/9 | 16.0 | 0.1475 | 0.5898 | -0.52 | -2.14 | no |
| Triplet (batch-hard) | +0.001 | [-0.004, +0.007] | 4/0/7 | 29.0 | 0.7646 | 1.0000 | -0.12 | -0.77 | no |
| Proxy-Anchor | -0.005 | [-0.008, -0.002] | 2/0/9 | 6.0 | 0.0137 | 0.0957 | -0.82 | -2.73 | no |
| ArcFace | +0.006 | [+0.001, +0.012] | 8/0/3 | 12.0 | 0.0674 | 0.4043 | +0.64 | +1.45 | no |
| CosFace | +0.003 | [-0.001, +0.009] | 5/0/6 | 27.0 | 0.6377 | 1.0000 | +0.18 | +0.14 | no |
| CE-MLP (norm.) | +0.001 | [-0.006, +0.012] | 2/0/9 | 21.0 | 0.3203 | 0.9609 | -0.36 | -2.00 | no |
| Sup-UMAP (tuned) | +0.144 | [+0.060, +0.246] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +6.18 | yes |
| Sup-UMAP (tuned, 16-D) | +0.076 | [+0.032, +0.133] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +4.45 | no |
| Sup-UMAP (default) | +0.130 | [+0.056, +0.240] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +6.36 | yes |
| LDA | +0.047 | [+0.028, +0.069] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +4.68 | no |
| PCA | +0.071 | [+0.051, +0.089] | 11/0/0 | 0.0 | 0.0010 | 0.0117 | +1.00 | +6.45 | yes |
