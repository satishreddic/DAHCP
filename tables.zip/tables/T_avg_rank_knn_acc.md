Average rank on Test 5-NN accuracy (1 = best).

| Method | Average rank |
|---|---|
| CE-MLP (norm.) | 2.0 |
| Proxy-Anchor | 3.32 |
| SupCon (same enc.) | 3.59 |
| CosFace | 4.41 |
| Triplet (batch-hard) | 4.55 |
| ArcFace | 5.14 |
| DACHP (ours) | 6.5 |
| LDA | 8.82 |
| Sup-UMAP (tuned, 16-D) | 9.91 |
| Sup-UMAP (default) | 11.23 |
| Sup-UMAP (tuned) | 11.32 |
| PCA | 11.32 |
| t-SNE | 11.36 |
| TriMap | 13.91 |
| PaCMAP | 14.0 |
| UMAP | 14.64 |
