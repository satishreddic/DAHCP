Spearman correlation between input-space diagnostics and DACHP's gain over tuned Sup-UMAP (n=11 datasets; exploratory, uncorrected).

| Diagnostic | Gain | Spearman ρ | p |
|---|---|---|---|
| knn_purity | Δ kNN | -0.64 | 0.035 |
| knn_purity | Δ Sil | -0.34 | 0.312 |
| false_nn_rate | Δ kNN | +0.25 | 0.450 |
| false_nn_rate | Δ Sil | +0.02 | 0.958 |
| hub_skew | Δ kNN | +0.12 | 0.729 |
| hub_skew | Δ Sil | -0.08 | 0.811 |
| dist_cv | Δ kNN | -0.58 | 0.060 |
| dist_cv | Δ Sil | -0.41 | 0.212 |
| rel_contrast | Δ kNN | -0.62 | 0.043 |
| rel_contrast | Δ Sil | +0.12 | 0.729 |
| n_over_d | Δ kNN | -0.51 | 0.109 |
| n_over_d | Δ Sil | -0.30 | 0.377 |
