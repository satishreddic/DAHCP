Datasets and held-out splits (split seed 0).

| Dataset | Domain | N | D | C | Regime | N/D | Train/Val/Test | Min class | Note |
|---|---|---|---|---|---|---|---|---|---|
| Breast Cancer | Medical (cytology features) | 569 | 30 | 2 | Low | 18.967 | 341/114/114 | 212 |  |
| Digits | Handwritten image | 1797 | 64 | 10 | Moderate | 28.078 | 1077/360/360 | 174 | full 1,797 samples (the original submission used a 1,000-sample subset) |
| Mice Protein | Proteomic expression | 1080 | 77 | 8 | Moderate | 14.026 | 645/225/210 | 105 | split grouped by mouse (replicates never cross train/test) |
| Annealing | Industrial process (steel annealing) | 898 | 38 | 5 | Moderate | 23.632 | 538/180/180 | 8 | UCI Annealing (OpenML id 2); categorical attributes ordinal-encoded |
| COIL-20 | Object image (rotation) | 1440 | 1024 | 20 | Ultra-High | 1.406 | 864/288/288 | 72 |  |
| CNAE-9 | Text (sparse term frequencies) | 1080 | 856 | 9 | High | 1.262 | 648/216/216 | 120 |  |
| MNIST | Handwritten image | 10000 | 784 | 10 | High | 12.755 | 6000/2000/2000 | 1000 | stratified subset, 1000 per class |
| Fashion-MNIST | Natural image | 10000 | 784 | 10 | High | 12.755 | 6000/2000/2000 | 1000 | stratified subset, 1000 per class |
| HAR | Inertial sensor signal (time+frequency features) | 10299 | 561 | 6 | High | 18.358 | 6179/2060/2060 | 1406 | subject identifiers not available in the OpenML release; random stratified split |
| ISOLET | Speech signal (spectral features) | 7797 | 617 | 26 | High | 12.637 | 4677/1560/1560 | 298 | speaker identifiers not available in the OpenML release; random stratified split |
| Olivetti Faces | Face image | 400 | 4096 | 40 | Ultra-High | 0.098 | 240/80/80 | 10 |  |
