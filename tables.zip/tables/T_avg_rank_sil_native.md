Average rank on Test Silhouette (native dim.) (1 = best).

| Method | Average rank |
|---|---|
| Proxy-Anchor | 2.64 |
| DACHP (ours) | 2.91 |
| SupCon (same enc.) | 3.0 |
| Triplet (batch-hard) | 5.45 |
| CosFace | 5.82 |
| CE-MLP (norm.) | 6.55 |
| Sup-UMAP (tuned, 16-D) | 6.55 |
| ArcFace | 7.36 |
| Sup-UMAP (tuned) | 9.5 |
| Sup-UMAP (default) | 9.5 |
| LDA | 10.64 |
| PaCMAP | 11.82 |
| UMAP | 12.82 |
| TriMap | 13.18 |
| t-SNE | 13.27 |
| PCA | 15.0 |
