Average rank on Test Silhouette (2-D) (1 = best).

| Method | Average rank |
|---|---|
| DACHP (ours) | 3.18 |
| Sup-UMAP (tuned) | 5.05 |
| Sup-UMAP (default) | 5.41 |
| Sup-UMAP (tuned, 16-D) | 5.64 |
| SupCon (same enc.) | 5.73 |
| Proxy-Anchor | 7.36 |
| Triplet (batch-hard) | 7.55 |
| CE-MLP (norm.) | 8.36 |
| PaCMAP | 8.36 |
| UMAP | 10.09 |
| TriMap | 10.09 |
| t-SNE | 10.18 |
| CosFace | 10.45 |
| ArcFace | 11.18 |
| LDA | 12.0 |
| PCA | 15.36 |
