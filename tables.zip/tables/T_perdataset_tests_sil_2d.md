Per-dataset paired comparison of DACHP (ours) vs each method on Test Silhouette (2-D) over the 5 held-out splits; Holm correction across methods within each dataset.

| Dataset | vs | Mean Δ | 95% boot CI | p (paired t) | p Holm | Sig. |
|---|---|---|---|---|---|---|
| Breast Cancer | SupCon (same enc.) | +0.034 | [+0.018, +0.050] | 0.0200 | 0.1599 | no |
| Breast Cancer | Triplet (batch-hard) | -0.016 | [-0.034, +0.003] | 0.2022 | 0.8087 | no |
| Breast Cancer | Proxy-Anchor | -0.011 | [-0.026, +0.003] | 0.2517 | 0.8087 | no |
| Breast Cancer | ArcFace | +0.015 | [+0.002, +0.027] | 0.1041 | 0.5204 | no |
| Breast Cancer | CosFace | +0.038 | [+0.027, +0.048] | 0.0031 | 0.0277 | yes |
| Breast Cancer | CE-MLP (norm.) | +0.003 | [-0.012, +0.016] | 0.6882 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (tuned) | +0.095 | [+0.044, +0.151] | 0.0369 | 0.2583 | no |
| Breast Cancer | Sup-UMAP (tuned, 16-D) | -0.006 | [-0.026, +0.011] | 0.6153 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (default) | +0.095 | [+0.044, +0.151] | 0.0369 | 0.2583 | no |
| Breast Cancer | UMAP | +0.347 | [+0.316, +0.379] | 0.0000 | 0.0006 | yes |
| Breast Cancer | LDA | +0.202 | [+0.181, +0.219] | 0.0001 | 0.0006 | yes |
| Breast Cancer | PCA | +0.407 | [+0.377, +0.437] | 0.0000 | 0.0004 | yes |
| Breast Cancer | t-SNE | +0.354 | [+0.332, +0.387] | 0.0000 | 0.0004 | yes |
| Breast Cancer | PaCMAP | +0.364 | [+0.334, +0.396] | 0.0000 | 0.0005 | yes |
| Breast Cancer | TriMap | +0.290 | [+0.247, +0.333] | 0.0003 | 0.0034 | yes |
| Digits | SupCon (same enc.) | +0.130 | [+0.082, +0.178] | 0.0083 | 0.0579 | no |
| Digits | Triplet (batch-hard) | +0.283 | [+0.236, +0.331] | 0.0005 | 0.0048 | yes |
| Digits | Proxy-Anchor | +0.151 | [+0.092, +0.206] | 0.0095 | 0.0579 | no |
| Digits | ArcFace | +0.244 | [+0.179, +0.309] | 0.0027 | 0.0213 | yes |
| Digits | CosFace | +0.277 | [+0.234, +0.323] | 0.0004 | 0.0046 | yes |
| Digits | CE-MLP (norm.) | +0.341 | [+0.305, +0.378] | 0.0001 | 0.0012 | yes |
| Digits | Sup-UMAP (tuned) | -0.217 | [-0.255, -0.182] | 0.0005 | 0.0048 | yes |
| Digits | Sup-UMAP (tuned, 16-D) | -0.178 | [-0.241, -0.101] | 0.0109 | 0.0579 | no |
| Digits | Sup-UMAP (default) | -0.213 | [-0.243, -0.186] | 0.0002 | 0.0025 | yes |
| Digits | UMAP | -0.056 | [-0.090, -0.023] | 0.0394 | 0.1577 | no |
| Digits | LDA | +0.334 | [+0.290, +0.374] | 0.0002 | 0.0021 | yes |
| Digits | PCA | +0.435 | [+0.397, +0.477] | 0.0000 | 0.0006 | yes |
| Digits | t-SNE | +0.001 | [-0.036, +0.035] | 0.9698 | 1.0000 | no |
| Digits | PaCMAP | -0.052 | [-0.087, -0.028] | 0.0401 | 0.1577 | no |
| Digits | TriMap | +0.003 | [-0.026, +0.025] | 0.8287 | 1.0000 | no |
| Mice Protein | SupCon (same enc.) | -0.083 | [-0.266, +0.035] | 0.4124 | 1.0000 | no |
| Mice Protein | Triplet (batch-hard) | -0.026 | [-0.126, +0.049] | 0.6516 | 1.0000 | no |
| Mice Protein | Proxy-Anchor | +0.072 | [+0.022, +0.122] | 0.0669 | 0.6023 | no |
| Mice Protein | ArcFace | +0.095 | [-0.009, +0.155] | 0.1392 | 1.0000 | no |
| Mice Protein | CosFace | +0.142 | [+0.063, +0.206] | 0.0273 | 0.3282 | no |
| Mice Protein | CE-MLP (norm.) | +0.012 | [-0.046, +0.070] | 0.7390 | 1.0000 | no |
| Mice Protein | Sup-UMAP (tuned) | +0.159 | [+0.058, +0.222] | 0.0340 | 0.3396 | no |
| Mice Protein | Sup-UMAP (tuned, 16-D) | +0.203 | [+0.095, +0.285] | 0.0228 | 0.3007 | no |
| Mice Protein | Sup-UMAP (default) | +0.161 | [+0.100, +0.206] | 0.0064 | 0.0967 | no |
| Mice Protein | UMAP | +0.179 | [+0.073, +0.255] | 0.0287 | 0.3282 | no |
| Mice Protein | LDA | -0.069 | [-0.201, +0.020] | 0.3599 | 1.0000 | no |
| Mice Protein | PCA | +0.160 | [+0.073, +0.220] | 0.0215 | 0.3007 | no |
| Mice Protein | t-SNE | -0.046 | [-0.148, +0.029] | 0.4245 | 1.0000 | no |
| Mice Protein | PaCMAP | -0.067 | [-0.162, +0.029] | 0.2957 | 1.0000 | no |
| Mice Protein | TriMap | -0.059 | [-0.147, +0.019] | 0.2984 | 1.0000 | no |
| Annealing | SupCon (same enc.) | -0.009 | [-0.114, +0.049] | 0.8653 | 0.8653 | no |
| Annealing | Triplet (batch-hard) | +0.288 | [+0.186, +0.390] | 0.0083 | 0.0169 | yes |
| Annealing | Proxy-Anchor | +0.221 | [+0.150, +0.292] | 0.0056 | 0.0169 | yes |
| Annealing | ArcFace | +0.220 | [+0.169, +0.270] | 0.0014 | 0.0098 | yes |
| Annealing | CosFace | +0.231 | [+0.197, +0.269] | 0.0004 | 0.0040 | yes |
| Annealing | CE-MLP (norm.) | +0.578 | [+0.524, +0.630] | 0.0000 | 0.0007 | yes |
| Annealing | Sup-UMAP (tuned) | +0.577 | [+0.450, +0.697] | 0.0012 | 0.0098 | yes |
| Annealing | Sup-UMAP (tuned, 16-D) | +0.580 | [+0.440, +0.709] | 0.0017 | 0.0100 | yes |
| Annealing | Sup-UMAP (default) | +0.593 | [+0.439, +0.732] | 0.0021 | 0.0104 | yes |
| Annealing | UMAP | +0.897 | [+0.750, +1.044] | 0.0004 | 0.0040 | yes |
| Annealing | LDA | +0.568 | [+0.378, +0.709] | 0.0042 | 0.0169 | yes |
| Annealing | PCA | +0.869 | [+0.767, +0.970] | 0.0001 | 0.0016 | yes |
| Annealing | t-SNE | +0.887 | [+0.768, +0.995] | 0.0002 | 0.0019 | yes |
| Annealing | PaCMAP | +0.935 | [+0.825, +1.045] | 0.0001 | 0.0016 | yes |
| Annealing | TriMap | +0.940 | [+0.817, +1.063] | 0.0002 | 0.0019 | yes |
| COIL-20 | SupCon (same enc.) | +0.337 | [+0.218, +0.476] | 0.0114 | 0.0456 | yes |
| COIL-20 | Triplet (batch-hard) | +0.129 | [+0.090, +0.166] | 0.0047 | 0.0332 | yes |
| COIL-20 | Proxy-Anchor | +0.544 | [+0.475, +0.596] | 0.0001 | 0.0016 | yes |
| COIL-20 | ArcFace | +0.408 | [+0.349, +0.468] | 0.0003 | 0.0034 | yes |
| COIL-20 | CosFace | +0.341 | [+0.297, +0.383] | 0.0002 | 0.0020 | yes |
| COIL-20 | CE-MLP (norm.) | +0.405 | [+0.356, +0.439] | 0.0001 | 0.0011 | yes |
| COIL-20 | Sup-UMAP (tuned) | +0.301 | [+0.225, +0.365] | 0.0016 | 0.0142 | yes |
| COIL-20 | Sup-UMAP (tuned, 16-D) | +0.090 | [+0.025, +0.143] | 0.0631 | 0.1894 | no |
| COIL-20 | Sup-UMAP (default) | -0.010 | [-0.073, +0.052] | 0.7878 | 0.7878 | no |
| COIL-20 | UMAP | +0.180 | [+0.118, +0.242] | 0.0073 | 0.0367 | yes |
| COIL-20 | LDA | +0.585 | [+0.516, +0.662] | 0.0002 | 0.0018 | yes |
| COIL-20 | PCA | +0.657 | [+0.601, +0.713] | 0.0000 | 0.0006 | yes |
| COIL-20 | t-SNE | +0.263 | [+0.197, +0.330] | 0.0024 | 0.0191 | yes |
| COIL-20 | PaCMAP | +0.081 | [+0.017, +0.145] | 0.0931 | 0.1894 | no |
| COIL-20 | TriMap | +0.188 | [+0.133, +0.243] | 0.0047 | 0.0332 | yes |
| CNAE-9 | SupCon (same enc.) | +0.196 | [+0.093, +0.298] | 0.0293 | 0.1760 | no |
| CNAE-9 | Triplet (batch-hard) | +0.152 | [+0.035, +0.256] | 0.0757 | 0.3028 | no |
| CNAE-9 | Proxy-Anchor | +0.202 | [+0.118, +0.285] | 0.0129 | 0.1288 | no |
| CNAE-9 | ArcFace | +0.267 | [+0.177, +0.335] | 0.0047 | 0.0545 | no |
| CNAE-9 | CosFace | +0.189 | [+0.083, +0.298] | 0.0368 | 0.1841 | no |
| CNAE-9 | CE-MLP (norm.) | +0.255 | [+0.137, +0.358] | 0.0144 | 0.1296 | no |
| CNAE-9 | Sup-UMAP (tuned) | +0.089 | [+0.009, +0.168] | 0.1331 | 0.3994 | no |
| CNAE-9 | Sup-UMAP (tuned, 16-D) | +0.127 | [-0.003, +0.240] | 0.1434 | 0.3994 | no |
| CNAE-9 | Sup-UMAP (default) | +0.005 | [-0.061, +0.063] | 0.8940 | 0.8940 | no |
| CNAE-9 | UMAP | +0.179 | [+0.085, +0.257] | 0.0207 | 0.1655 | no |
| CNAE-9 | LDA | +0.639 | [+0.561, +0.718] | 0.0002 | 0.0021 | yes |
| CNAE-9 | PCA | +0.758 | [+0.708, +0.817] | 0.0000 | 0.0003 | yes |
| CNAE-9 | t-SNE | +0.471 | [+0.366, +0.551] | 0.0009 | 0.0120 | yes |
| CNAE-9 | PaCMAP | +0.209 | [+0.103, +0.298] | 0.0229 | 0.1655 | no |
| CNAE-9 | TriMap | +0.262 | [+0.183, +0.334] | 0.0045 | 0.0545 | no |
| MNIST | SupCon (same enc.) | +0.161 | [+0.102, +0.243] | 0.0194 | 0.0970 | no |
| MNIST | Triplet (batch-hard) | +0.248 | [+0.215, +0.281] | 0.0002 | 0.0012 | yes |
| MNIST | Proxy-Anchor | +0.181 | [+0.160, +0.212] | 0.0003 | 0.0017 | yes |
| MNIST | ArcFace | +0.425 | [+0.399, +0.459] | 0.0000 | 0.0002 | yes |
| MNIST | CosFace | +0.343 | [+0.298, +0.381] | 0.0001 | 0.0010 | yes |
| MNIST | CE-MLP (norm.) | +0.170 | [+0.090, +0.244] | 0.0203 | 0.0970 | no |
| MNIST | Sup-UMAP (tuned) | +0.027 | [-0.017, +0.071] | 0.3420 | 0.6841 | no |
| MNIST | Sup-UMAP (tuned, 16-D) | +0.138 | [+0.073, +0.215] | 0.0284 | 0.0970 | no |
| MNIST | Sup-UMAP (default) | +0.027 | [-0.017, +0.071] | 0.3420 | 0.6841 | no |
| MNIST | UMAP | +0.342 | [+0.314, +0.371] | 0.0000 | 0.0003 | yes |
| MNIST | LDA | +0.597 | [+0.564, +0.630] | 0.0000 | 0.0001 | yes |
| MNIST | PCA | +0.719 | [+0.697, +0.741] | 0.0000 | 0.0000 | yes |
| MNIST | t-SNE | +0.477 | [+0.455, +0.500] | 0.0000 | 0.0000 | yes |
| MNIST | PaCMAP | +0.372 | [+0.338, +0.419] | 0.0001 | 0.0009 | yes |
| MNIST | TriMap | +0.417 | [+0.373, +0.462] | 0.0001 | 0.0008 | yes |
| Fashion-MNIST | SupCon (same enc.) | +0.050 | [+0.015, +0.089] | 0.0850 | 0.0850 | no |
| Fashion-MNIST | Triplet (batch-hard) | +0.376 | [+0.316, +0.436] | 0.0004 | 0.0024 | yes |
| Fashion-MNIST | Proxy-Anchor | +0.262 | [+0.243, +0.282] | 0.0000 | 0.0002 | yes |
| Fashion-MNIST | ArcFace | +0.458 | [+0.434, +0.484] | 0.0000 | 0.0001 | yes |
| Fashion-MNIST | CosFace | +0.423 | [+0.377, +0.486] | 0.0002 | 0.0019 | yes |
| Fashion-MNIST | CE-MLP (norm.) | +0.247 | [+0.178, +0.310] | 0.0025 | 0.0101 | yes |
| Fashion-MNIST | Sup-UMAP (tuned) | +0.114 | [+0.070, +0.162] | 0.0109 | 0.0326 | yes |
| Fashion-MNIST | Sup-UMAP (tuned, 16-D) | +0.252 | [+0.212, +0.307] | 0.0008 | 0.0038 | yes |
| Fashion-MNIST | Sup-UMAP (default) | +0.114 | [+0.070, +0.162] | 0.0109 | 0.0326 | yes |
| Fashion-MNIST | UMAP | +0.301 | [+0.262, +0.347] | 0.0002 | 0.0019 | yes |
| Fashion-MNIST | LDA | +0.401 | [+0.364, +0.438] | 0.0000 | 0.0005 | yes |
| Fashion-MNIST | PCA | +0.535 | [+0.504, +0.573] | 0.0000 | 0.0002 | yes |
| Fashion-MNIST | t-SNE | +0.322 | [+0.288, +0.364] | 0.0001 | 0.0012 | yes |
| Fashion-MNIST | PaCMAP | +0.293 | [+0.254, +0.339] | 0.0003 | 0.0019 | yes |
| Fashion-MNIST | TriMap | +0.318 | [+0.283, +0.358] | 0.0001 | 0.0012 | yes |
| HAR | SupCon (same enc.) | +0.286 | [+0.241, +0.321] | 0.0002 | 0.0008 | yes |
| HAR | Triplet (batch-hard) | +0.290 | [+0.211, +0.368] | 0.0030 | 0.0060 | yes |
| HAR | Proxy-Anchor | +0.273 | [+0.251, +0.304] | 0.0001 | 0.0004 | yes |
| HAR | ArcFace | +0.495 | [+0.463, +0.527] | 0.0000 | 0.0001 | yes |
| HAR | CosFace | +0.314 | [+0.288, +0.341] | 0.0000 | 0.0003 | yes |
| HAR | CE-MLP (norm.) | +0.144 | [+0.095, +0.187] | 0.0059 | 0.0060 | yes |
| HAR | Sup-UMAP (tuned) | +0.222 | [+0.199, +0.244] | 0.0001 | 0.0004 | yes |
| HAR | Sup-UMAP (tuned, 16-D) | +0.192 | [+0.168, +0.218] | 0.0002 | 0.0008 | yes |
| HAR | Sup-UMAP (default) | +0.247 | [+0.226, +0.270] | 0.0000 | 0.0003 | yes |
| HAR | UMAP | +0.685 | [+0.674, +0.698] | 0.0000 | 0.0000 | yes |
| HAR | LDA | +0.730 | [+0.720, +0.740] | 0.0000 | 0.0000 | yes |
| HAR | PCA | +0.912 | [+0.906, +0.917] | 0.0000 | 0.0000 | yes |
| HAR | t-SNE | +0.673 | [+0.663, +0.682] | 0.0000 | 0.0000 | yes |
| HAR | PaCMAP | +0.678 | [+0.659, +0.702] | 0.0000 | 0.0000 | yes |
| HAR | TriMap | +0.708 | [+0.702, +0.713] | 0.0000 | 0.0000 | yes |
| ISOLET | SupCon (same enc.) | -0.042 | [-0.067, -0.017] | 0.0416 | 0.1247 | no |
| ISOLET | Triplet (batch-hard) | +0.129 | [+0.078, +0.183] | 0.0129 | 0.0514 | no |
| ISOLET | Proxy-Anchor | -0.115 | [-0.157, -0.072] | 0.0088 | 0.0438 | yes |
| ISOLET | ArcFace | +0.299 | [+0.285, +0.318] | 0.0000 | 0.0001 | yes |
| ISOLET | CosFace | +0.259 | [+0.230, +0.294] | 0.0002 | 0.0019 | yes |
| ISOLET | CE-MLP (norm.) | +0.051 | [+0.022, +0.092] | 0.0624 | 0.1248 | no |
| ISOLET | Sup-UMAP (tuned) | -0.139 | [-0.171, -0.100] | 0.0023 | 0.0206 | yes |
| ISOLET | Sup-UMAP (tuned, 16-D) | +0.003 | [-0.030, +0.036] | 0.8864 | 0.8864 | no |
| ISOLET | Sup-UMAP (default) | -0.213 | [-0.231, -0.186] | 0.0001 | 0.0013 | yes |
| ISOLET | UMAP | +0.093 | [+0.074, +0.120] | 0.0023 | 0.0206 | yes |
| ISOLET | LDA | +0.272 | [+0.243, +0.302] | 0.0001 | 0.0010 | yes |
| ISOLET | PCA | +0.388 | [+0.361, +0.417] | 0.0000 | 0.0002 | yes |
| ISOLET | t-SNE | +0.111 | [+0.085, +0.141] | 0.0019 | 0.0186 | yes |
| ISOLET | PaCMAP | +0.092 | [+0.067, +0.119] | 0.0029 | 0.0206 | yes |
| ISOLET | TriMap | +0.095 | [+0.063, +0.125] | 0.0049 | 0.0296 | yes |
| Olivetti Faces | SupCon (same enc.) | +0.105 | [+0.062, +0.153] | 0.0162 | 0.1296 | no |
| Olivetti Faces | Triplet (batch-hard) | +0.012 | [-0.065, +0.089] | 0.7891 | 1.0000 | no |
| Olivetti Faces | Proxy-Anchor | +0.128 | [+0.056, +0.187] | 0.0276 | 0.1935 | no |
| Olivetti Faces | ArcFace | +0.234 | [+0.203, +0.260] | 0.0001 | 0.0019 | yes |
| Olivetti Faces | CosFace | +0.259 | [+0.183, +0.332] | 0.0038 | 0.0386 | yes |
| Olivetti Faces | CE-MLP (norm.) | +0.206 | [+0.158, +0.247] | 0.0013 | 0.0156 | yes |
| Olivetti Faces | Sup-UMAP (tuned) | -0.069 | [-0.181, +0.056] | 0.3625 | 1.0000 | no |
| Olivetti Faces | Sup-UMAP (tuned, 16-D) | -0.062 | [-0.135, +0.017] | 0.2170 | 1.0000 | no |
| Olivetti Faces | Sup-UMAP (default) | +0.079 | [+0.048, +0.110] | 0.0130 | 0.1166 | no |
| Olivetti Faces | UMAP | +0.220 | [+0.158, +0.282] | 0.0035 | 0.0386 | yes |
| Olivetti Faces | LDA | +0.150 | [+0.131, +0.168] | 0.0001 | 0.0019 | yes |
| Olivetti Faces | PCA | +0.344 | [+0.321, +0.366] | 0.0000 | 0.0002 | yes |
| Olivetti Faces | t-SNE | -0.051 | [-0.130, +0.024] | 0.3107 | 1.0000 | no |
| Olivetti Faces | PaCMAP | -0.064 | [-0.131, +0.003] | 0.1701 | 1.0000 | no |
| Olivetti Faces | TriMap | +0.000 | [-0.068, +0.068] | 0.9980 | 1.0000 | no |
