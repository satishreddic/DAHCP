Wall-clock training/fitting time (mean over 5 runs) and DACHP peak memory where it was recorded. Times depend on the hardware used.

| Dataset | DACHP (ours) time (s) | DACHP peak memory (MB) | DACHP params | DACHP H1/H2 | Batch | SupCon (same enc.) time (s) | Sup-UMAP (tuned) time (s) | UMAP time (s) | t-SNE time (s) |
|---|---|---|---|---|---|---|---|---|---|
| Breast Cancer | 1.7 | 33 | 22785 | 128/64 | 341 | 0.9 | 1.0 | 0.9 | 2.9 |
| Digits | 2.2 | 164 | 27137 | 128/64 | 1077 | 0.9 | 5.3 | 4.0 | 8.6 |
| Mice Protein | 1.8 | 72 | 38434 | 154/77 | 645 | 0.8 | 1.7 | 2.2 | 5.1 |
| Annealing | 1.7 | 56 | 23809 | 128/64 | 538 | 0.9 | 1.7 | 1.5 | 3.9 |
| COIL-20 | 2.0 | 131 | 635049 | 432/216 | 864 | 0.8 | 3.5 | 3.7 | 6.5 |
| CNAE-9 | 1.9 | 83 | 387135 | 324/162 | 648 | 0.8 | 2.0 | 2.4 | 6.3 |
| MNIST | 25.2 | 127 | 3707057 | 1568/784 | 512 | 17.7 | 15.0 | 12.7 | 47.7 |
| Fashion-MNIST | 25.2 | 127 | 3707057 | 1568/784 | 512 | 17.8 | 14.1 | 12.3 | 40.3 |
| HAR | 22.5 | 97 | 1902318 | 1122/561 | 512 | 12.9 | 15.9 | 12.1 | 49.8 |
| ISOLET | 32.9 | 97 | 2299414 | 1234/617 | 256 | 19.5 | 12.5 | 10.7 | 32.1 |
| Olivetti Faces | 1.8 | 39 | 543233 | 128/64 | 240 | 0.9 | 0.6 | 1.7 | 2.7 |
