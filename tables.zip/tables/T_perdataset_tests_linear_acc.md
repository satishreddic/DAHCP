Per-dataset paired comparison of DACHP (ours) vs each method on Test linear-probe accuracy over the 5 held-out splits; Holm correction across methods within each dataset.

| Dataset | vs | Mean Δ | 95% boot CI | p (paired t) | p Holm | Sig. |
|---|---|---|---|---|---|---|
| Breast Cancer | SupCon (same enc.) | +0.002 | [+0.000, +0.005] | 0.3739 | 1.0000 | no |
| Breast Cancer | Triplet (batch-hard) | +0.000 | [-0.007, +0.007] | 1.0000 | 1.0000 | no |
| Breast Cancer | Proxy-Anchor | -0.004 | [-0.009, +0.004] | 0.3739 | 1.0000 | no |
| Breast Cancer | ArcFace | -0.002 | [-0.005, +0.000] | 0.3739 | 1.0000 | no |
| Breast Cancer | CosFace | -0.002 | [-0.007, +0.004] | 0.6213 | 1.0000 | no |
| Breast Cancer | CE-MLP (norm.) | -0.005 | [-0.009, -0.002] | 0.0705 | 0.8458 | no |
| Breast Cancer | Sup-UMAP (tuned) | +0.005 | [-0.004, +0.012] | 0.3046 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (tuned, 16-D) | +0.004 | [-0.005, +0.012] | 0.5415 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (default) | +0.005 | [-0.004, +0.012] | 0.3046 | 1.0000 | no |
| Breast Cancer | UMAP | +0.012 | [+0.005, +0.021] | 0.0516 | 0.6709 | no |
| Breast Cancer | LDA | +0.009 | [+0.004, +0.014] | 0.0341 | 0.5116 | no |
| Breast Cancer | PCA | +0.000 | [-0.007, +0.007] | 1.0000 | 1.0000 | no |
| Breast Cancer | t-SNE | +0.023 | [+0.005, +0.040] | 0.0897 | 0.9863 | no |
| Breast Cancer | PaCMAP | +0.032 | [+0.014, +0.049] | 0.0367 | 0.5135 | no |
| Breast Cancer | TriMap | +0.011 | [+0.002, +0.019] | 0.1087 | 1.0000 | no |
| Digits | SupCon (same enc.) | -0.014 | [-0.019, -0.008] | 0.0118 | 0.1064 | no |
| Digits | Triplet (batch-hard) | -0.006 | [-0.011, +0.000] | 0.1302 | 0.5206 | no |
| Digits | Proxy-Anchor | -0.013 | [-0.017, -0.008] | 0.0078 | 0.0853 | no |
| Digits | ArcFace | -0.014 | [-0.021, -0.008] | 0.0202 | 0.1427 | no |
| Digits | CosFace | -0.014 | [-0.018, -0.008] | 0.0089 | 0.0886 | no |
| Digits | CE-MLP (norm.) | -0.019 | [-0.023, -0.015] | 0.0011 | 0.0156 | yes |
| Digits | Sup-UMAP (tuned) | +0.031 | [+0.023, +0.039] | 0.0030 | 0.0362 | yes |
| Digits | Sup-UMAP (tuned, 16-D) | +0.007 | [-0.005, +0.018] | 0.3243 | 0.6485 | no |
| Digits | Sup-UMAP (default) | +0.032 | [+0.002, +0.075] | 0.2091 | 0.6273 | no |
| Digits | UMAP | +0.074 | [+0.038, +0.119] | 0.0316 | 0.1899 | no |
| Digits | LDA | +0.004 | [-0.003, +0.010] | 0.3383 | 0.6485 | no |
| Digits | PCA | +0.026 | [+0.021, +0.031] | 0.0008 | 0.0120 | yes |
| Digits | t-SNE | +0.081 | [+0.041, +0.143] | 0.0618 | 0.3091 | no |
| Digits | PaCMAP | +0.123 | [+0.084, +0.186] | 0.0178 | 0.1427 | no |
| Digits | TriMap | +0.113 | [+0.089, +0.137] | 0.0013 | 0.0167 | yes |
| Mice Protein | SupCon (same enc.) | -0.008 | [-0.035, +0.015] | 0.5980 | 1.0000 | no |
| Mice Protein | Triplet (batch-hard) | +0.002 | [-0.023, +0.023] | 0.8743 | 1.0000 | no |
| Mice Protein | Proxy-Anchor | -0.010 | [-0.049, +0.028] | 0.6683 | 1.0000 | no |
| Mice Protein | ArcFace | +0.025 | [-0.037, +0.084] | 0.5013 | 1.0000 | no |
| Mice Protein | CosFace | +0.019 | [-0.022, +0.062] | 0.4445 | 1.0000 | no |
| Mice Protein | CE-MLP (norm.) | -0.005 | [-0.035, +0.025] | 0.7924 | 1.0000 | no |
| Mice Protein | Sup-UMAP (tuned) | +0.306 | [+0.269, +0.344] | 0.0002 | 0.0025 | yes |
| Mice Protein | Sup-UMAP (tuned, 16-D) | +0.133 | [+0.056, +0.179] | 0.0258 | 0.2575 | no |
| Mice Protein | Sup-UMAP (default) | +0.156 | [+0.076, +0.235] | 0.0289 | 0.2597 | no |
| Mice Protein | UMAP | +0.270 | [+0.175, +0.365] | 0.0069 | 0.0826 | no |
| Mice Protein | LDA | +0.029 | [-0.042, +0.099] | 0.5174 | 1.0000 | no |
| Mice Protein | PCA | +0.042 | [+0.003, +0.073] | 0.1041 | 0.8331 | no |
| Mice Protein | t-SNE | +0.234 | [+0.183, +0.287] | 0.0015 | 0.0204 | yes |
| Mice Protein | PaCMAP | +0.140 | [+0.086, +0.210] | 0.0157 | 0.1731 | no |
| Mice Protein | TriMap | +0.209 | [+0.136, +0.274] | 0.0062 | 0.0808 | no |
| Annealing | SupCon (same enc.) | +0.000 | [-0.007, +0.006] | 1.0000 | 1.0000 | no |
| Annealing | Triplet (batch-hard) | +0.004 | [-0.004, +0.012] | 0.4050 | 1.0000 | no |
| Annealing | Proxy-Anchor | -0.001 | [-0.009, +0.007] | 0.8149 | 1.0000 | no |
| Annealing | ArcFace | -0.001 | [-0.010, +0.007] | 0.8276 | 1.0000 | no |
| Annealing | CosFace | -0.002 | [-0.010, +0.007] | 0.6702 | 1.0000 | no |
| Annealing | CE-MLP (norm.) | +0.000 | [-0.007, +0.007] | 1.0000 | 1.0000 | no |
| Annealing | Sup-UMAP (tuned) | +0.081 | [+0.059, +0.103] | 0.0041 | 0.0284 | yes |
| Annealing | Sup-UMAP (tuned, 16-D) | +0.050 | [+0.038, +0.062] | 0.0021 | 0.0206 | yes |
| Annealing | Sup-UMAP (default) | +0.061 | [+0.043, +0.077] | 0.0030 | 0.0262 | yes |
| Annealing | UMAP | +0.159 | [+0.157, +0.161] | 0.0000 | 0.0000 | yes |
| Annealing | LDA | +0.024 | [+0.018, +0.030] | 0.0029 | 0.0262 | yes |
| Annealing | PCA | +0.099 | [+0.086, +0.113] | 0.0002 | 0.0026 | yes |
| Annealing | t-SNE | +0.152 | [+0.146, +0.162] | 0.0000 | 0.0001 | yes |
| Annealing | PaCMAP | +0.163 | [+0.147, +0.177] | 0.0000 | 0.0006 | yes |
| Annealing | TriMap | +0.176 | [+0.156, +0.200] | 0.0002 | 0.0019 | yes |
| COIL-20 | SupCon (same enc.) | -0.004 | [-0.009, -0.001] | 0.1778 | 0.5478 | no |
| COIL-20 | Triplet (batch-hard) | -0.007 | [-0.013, -0.003] | 0.0612 | 0.3060 | no |
| COIL-20 | Proxy-Anchor | -0.006 | [-0.013, -0.001] | 0.1369 | 0.5478 | no |
| COIL-20 | ArcFace | -0.006 | [-0.012, -0.001] | 0.1404 | 0.5478 | no |
| COIL-20 | CosFace | -0.005 | [-0.011, -0.001] | 0.2056 | 0.5478 | no |
| COIL-20 | CE-MLP (norm.) | -0.008 | [-0.012, -0.003] | 0.0402 | 0.2411 | no |
| COIL-20 | Sup-UMAP (tuned) | +0.294 | [+0.230, +0.383] | 0.0025 | 0.0221 | yes |
| COIL-20 | Sup-UMAP (tuned, 16-D) | +0.028 | [+0.019, +0.039] | 0.0082 | 0.0660 | no |
| COIL-20 | Sup-UMAP (default) | +0.062 | [+0.051, +0.074] | 0.0007 | 0.0065 | yes |
| COIL-20 | UMAP | +0.224 | [+0.214, +0.233] | 0.0000 | 0.0000 | yes |
| COIL-20 | LDA | +0.124 | [+0.104, +0.144] | 0.0005 | 0.0052 | yes |
| COIL-20 | PCA | +0.017 | [+0.010, +0.024] | 0.0143 | 0.1001 | no |
| COIL-20 | t-SNE | +0.254 | [+0.223, +0.285] | 0.0002 | 0.0021 | yes |
| COIL-20 | PaCMAP | +0.175 | [+0.147, +0.200] | 0.0003 | 0.0032 | yes |
| COIL-20 | TriMap | +0.216 | [+0.200, +0.232] | 0.0000 | 0.0002 | yes |
| CNAE-9 | SupCon (same enc.) | +0.000 | [-0.009, +0.009] | 1.0000 | 1.0000 | no |
| CNAE-9 | Triplet (batch-hard) | +0.004 | [-0.009, +0.015] | 0.6135 | 1.0000 | no |
| CNAE-9 | Proxy-Anchor | -0.006 | [-0.013, +0.000] | 0.1599 | 0.9596 | no |
| CNAE-9 | ArcFace | -0.003 | [-0.006, +0.002] | 0.3046 | 1.0000 | no |
| CNAE-9 | CosFace | -0.001 | [-0.004, +0.002] | 0.6213 | 1.0000 | no |
| CNAE-9 | CE-MLP (norm.) | -0.004 | [-0.012, +0.005] | 0.4766 | 1.0000 | no |
| CNAE-9 | Sup-UMAP (tuned) | +0.123 | [+0.081, +0.187] | 0.0197 | 0.1524 | no |
| CNAE-9 | Sup-UMAP (tuned, 16-D) | +0.074 | [+0.047, +0.113] | 0.0191 | 0.1524 | no |
| CNAE-9 | Sup-UMAP (default) | +0.081 | [+0.071, +0.090] | 0.0001 | 0.0019 | yes |
| CNAE-9 | UMAP | +0.130 | [+0.104, +0.156] | 0.0010 | 0.0099 | yes |
| CNAE-9 | LDA | +0.085 | [+0.058, +0.116] | 0.0063 | 0.0565 | no |
| CNAE-9 | PCA | +0.115 | [+0.096, +0.133] | 0.0004 | 0.0048 | yes |
| CNAE-9 | t-SNE | +0.380 | [+0.329, +0.431] | 0.0002 | 0.0028 | yes |
| CNAE-9 | PaCMAP | +0.173 | [+0.138, +0.204] | 0.0008 | 0.0089 | yes |
| CNAE-9 | TriMap | +0.207 | [+0.183, +0.234] | 0.0001 | 0.0019 | yes |
| MNIST | SupCon (same enc.) | -0.006 | [-0.007, -0.004] | 0.0027 | 0.0135 | yes |
| MNIST | Triplet (batch-hard) | -0.008 | [-0.012, -0.005] | 0.0150 | 0.0385 | yes |
| MNIST | Proxy-Anchor | -0.008 | [-0.011, -0.005] | 0.0090 | 0.0361 | yes |
| MNIST | ArcFace | -0.005 | [-0.006, -0.003] | 0.0128 | 0.0385 | yes |
| MNIST | CosFace | -0.005 | [-0.008, -0.003] | 0.0327 | 0.0385 | yes |
| MNIST | CE-MLP (norm.) | -0.010 | [-0.012, -0.008] | 0.0006 | 0.0036 | yes |
| MNIST | Sup-UMAP (tuned) | +0.035 | [+0.031, +0.039] | 0.0001 | 0.0008 | yes |
| MNIST | Sup-UMAP (tuned, 16-D) | +0.029 | [+0.025, +0.033] | 0.0002 | 0.0018 | yes |
| MNIST | Sup-UMAP (default) | +0.035 | [+0.031, +0.039] | 0.0001 | 0.0008 | yes |
| MNIST | UMAP | +0.139 | [+0.128, +0.151] | 0.0000 | 0.0004 | yes |
| MNIST | LDA | +0.087 | [+0.080, +0.092] | 0.0000 | 0.0002 | yes |
| MNIST | PCA | +0.096 | [+0.094, +0.097] | 0.0000 | 0.0000 | yes |
| MNIST | t-SNE | +0.236 | [+0.196, +0.278] | 0.0005 | 0.0036 | yes |
| MNIST | PaCMAP | +0.171 | [+0.159, +0.183] | 0.0000 | 0.0002 | yes |
| MNIST | TriMap | +0.200 | [+0.189, +0.215] | 0.0000 | 0.0002 | yes |
| Fashion-MNIST | SupCon (same enc.) | -0.002 | [-0.006, +0.001] | 0.3698 | 1.0000 | no |
| Fashion-MNIST | Triplet (batch-hard) | +0.026 | [+0.023, +0.029] | 0.0001 | 0.0014 | yes |
| Fashion-MNIST | Proxy-Anchor | -0.006 | [-0.010, -0.003] | 0.0361 | 0.1803 | no |
| Fashion-MNIST | ArcFace | +0.002 | [-0.003, +0.007] | 0.4710 | 1.0000 | no |
| Fashion-MNIST | CosFace | +0.000 | [-0.004, +0.003] | 1.0000 | 1.0000 | no |
| Fashion-MNIST | CE-MLP (norm.) | -0.005 | [-0.010, +0.000] | 0.1831 | 0.7324 | no |
| Fashion-MNIST | Sup-UMAP (tuned) | +0.054 | [+0.045, +0.066] | 0.0010 | 0.0072 | yes |
| Fashion-MNIST | Sup-UMAP (tuned, 16-D) | +0.046 | [+0.037, +0.055] | 0.0009 | 0.0072 | yes |
| Fashion-MNIST | Sup-UMAP (default) | +0.054 | [+0.045, +0.066] | 0.0010 | 0.0072 | yes |
| Fashion-MNIST | UMAP | +0.153 | [+0.145, +0.162] | 0.0000 | 0.0001 | yes |
| Fashion-MNIST | LDA | +0.055 | [+0.046, +0.064] | 0.0004 | 0.0032 | yes |
| Fashion-MNIST | PCA | +0.082 | [+0.077, +0.086] | 0.0000 | 0.0001 | yes |
| Fashion-MNIST | t-SNE | +0.163 | [+0.159, +0.167] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | PaCMAP | +0.143 | [+0.135, +0.154] | 0.0000 | 0.0001 | yes |
| Fashion-MNIST | TriMap | +0.160 | [+0.153, +0.166] | 0.0000 | 0.0000 | yes |
| HAR | SupCon (same enc.) | +0.001 | [-0.000, +0.002] | 0.2326 | 0.9303 | no |
| HAR | Triplet (batch-hard) | -0.001 | [-0.002, +0.001] | 0.4581 | 0.9303 | no |
| HAR | Proxy-Anchor | -0.001 | [-0.003, +0.001] | 0.5995 | 0.9303 | no |
| HAR | ArcFace | +0.002 | [+0.001, +0.003] | 0.0129 | 0.0775 | no |
| HAR | CosFace | +0.003 | [+0.001, +0.004] | 0.0248 | 0.1240 | no |
| HAR | CE-MLP (norm.) | -0.001 | [-0.003, +0.000] | 0.2501 | 0.9303 | no |
| HAR | Sup-UMAP (tuned) | +0.037 | [+0.035, +0.040] | 0.0000 | 0.0002 | yes |
| HAR | Sup-UMAP (tuned, 16-D) | +0.035 | [+0.033, +0.037] | 0.0000 | 0.0001 | yes |
| HAR | Sup-UMAP (default) | +0.058 | [+0.049, +0.066] | 0.0003 | 0.0031 | yes |
| HAR | UMAP | +0.237 | [+0.215, +0.268] | 0.0001 | 0.0010 | yes |
| HAR | LDA | +0.005 | [+0.004, +0.006] | 0.0035 | 0.0246 | yes |
| HAR | PCA | +0.095 | [+0.088, +0.101] | 0.0000 | 0.0002 | yes |
| HAR | t-SNE | +0.156 | [+0.150, +0.162] | 0.0000 | 0.0000 | yes |
| HAR | PaCMAP | +0.250 | [+0.204, +0.318] | 0.0017 | 0.0140 | yes |
| HAR | TriMap | +0.218 | [+0.207, +0.230] | 0.0000 | 0.0001 | yes |
| ISOLET | SupCon (same enc.) | +0.001 | [-0.001, +0.003] | 0.2859 | 0.8578 | no |
| ISOLET | Triplet (batch-hard) | +0.001 | [-0.001, +0.003] | 0.5913 | 0.8578 | no |
| ISOLET | Proxy-Anchor | -0.001 | [-0.002, +0.001] | 0.3508 | 0.8578 | no |
| ISOLET | ArcFace | +0.004 | [+0.002, +0.007] | 0.0384 | 0.1919 | no |
| ISOLET | CosFace | +0.002 | [+0.000, +0.004] | 0.1193 | 0.4773 | no |
| ISOLET | CE-MLP (norm.) | -0.005 | [-0.007, -0.003] | 0.0050 | 0.0298 | yes |
| ISOLET | Sup-UMAP (tuned) | +0.114 | [+0.096, +0.134] | 0.0004 | 0.0031 | yes |
| ISOLET | Sup-UMAP (tuned, 16-D) | +0.090 | [+0.082, +0.096] | 0.0000 | 0.0002 | yes |
| ISOLET | Sup-UMAP (default) | +0.126 | [+0.111, +0.141] | 0.0001 | 0.0012 | yes |
| ISOLET | UMAP | +0.354 | [+0.345, +0.365] | 0.0000 | 0.0000 | yes |
| ISOLET | LDA | +0.044 | [+0.039, +0.051] | 0.0002 | 0.0013 | yes |
| ISOLET | PCA | +0.121 | [+0.114, +0.126] | 0.0000 | 0.0000 | yes |
| ISOLET | t-SNE | +0.361 | [+0.344, +0.379] | 0.0000 | 0.0000 | yes |
| ISOLET | PaCMAP | +0.373 | [+0.353, +0.390] | 0.0000 | 0.0000 | yes |
| ISOLET | TriMap | +0.329 | [+0.322, +0.336] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | SupCon (same enc.) | -0.045 | [-0.055, -0.035] | 0.0021 | 0.0170 | yes |
| Olivetti Faces | Triplet (batch-hard) | -0.035 | [-0.050, -0.022] | 0.0135 | 0.0943 | no |
| Olivetti Faces | Proxy-Anchor | -0.035 | [-0.052, -0.017] | 0.0249 | 0.1494 | no |
| Olivetti Faces | ArcFace | -0.012 | [-0.035, +0.015] | 0.4300 | 0.9208 | no |
| Olivetti Faces | CosFace | -0.010 | [-0.025, +0.002] | 0.2943 | 0.9208 | no |
| Olivetti Faces | CE-MLP (norm.) | -0.020 | [-0.035, -0.007] | 0.0777 | 0.3887 | no |
| Olivetti Faces | Sup-UMAP (tuned) | +0.478 | [+0.425, +0.530] | 0.0001 | 0.0010 | yes |
| Olivetti Faces | Sup-UMAP (tuned, 16-D) | +0.290 | [+0.257, +0.323] | 0.0001 | 0.0010 | yes |
| Olivetti Faces | Sup-UMAP (default) | +0.590 | [+0.530, +0.633] | 0.0000 | 0.0004 | yes |
| Olivetti Faces | UMAP | +0.677 | [+0.650, +0.710] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | LDA | -0.007 | [-0.027, +0.018] | 0.5913 | 0.9208 | no |
| Olivetti Faces | PCA | +0.013 | [-0.002, +0.028] | 0.2302 | 0.9208 | no |
| Olivetti Faces | t-SNE | +0.610 | [+0.595, +0.630] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | PaCMAP | +0.653 | [+0.622, +0.687] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | TriMap | +0.585 | [+0.555, +0.620] | 0.0000 | 0.0001 | yes |
