Input-space neighbourhood diagnostics (standardised training split): 10-NN label purity, 1-NN false-neighbour rate, hubness skewness of 10-occurrence, coefficient of variation of pairwise distances, median relative contrast (Dmax−Dmin)/Dmin, and N/D; with DACHP's gain over tuned Supervised UMAP.

| Dataset | knn_purity | false_nn_rate | hub_skew | dist_cv | rel_contrast | n_over_d | Δ kNN (DACHP−SupUMAP) | Δ Sil (DACHP−SupUMAP) |
|---|---|---|---|---|---|---|---|---|
| Breast Cancer | 0.930 | 0.053 | 0.922 | 0.467 | 9.044 | 11.367 | +0.007 | +0.084 |
| Digits | 0.919 | 0.021 | 0.795 | 0.328 | 10.526 | 16.828 | +0.023 | -0.081 |
| Mice Protein | 0.873 | 0.003 | 0.393 | 0.278 | 7.957 | 8.377 | +0.163 | +0.224 |
| Annealing | 0.859 | 0.056 | 0.757 | 0.376 | 23.769 | 14.158 | +0.050 | +0.554 |
| COIL-20 | 0.837 | 0.017 | 0.633 | 0.243 | 11.785 | 0.844 | +0.048 | +0.465 |
| CNAE-9 | 0.588 | 0.140 | 9.259 | 0.480 | 6.525 | 0.757 | +0.090 | +0.225 |
| MNIST | 0.785 | 0.122 | 0.963 | 0.411 | 10.197 | 3.827 | +0.035 | +0.208 |
| Fashion-MNIST | 0.713 | 0.217 | 1.850 | 0.290 | 9.960 | 3.827 | +0.056 | +0.206 |
| HAR | 0.847 | 0.070 | 2.190 | 0.401 | 12.195 | 5.348 | +0.037 | +0.233 |
| ISOLET | 0.747 | 0.172 | 1.575 | 0.173 | 2.379 | 4.862 | +0.097 | +0.418 |
| Olivetti Faces | 0.302 | 0.108 | 1.295 | 0.209 | 2.220 | 0.059 | +0.277 | +0.337 |
