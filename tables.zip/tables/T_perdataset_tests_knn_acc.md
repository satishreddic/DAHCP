Per-dataset paired comparison of DACHP (ours) vs each method on Test 5-NN accuracy over the 5 held-out splits; Holm correction across methods within each dataset.

| Dataset | vs | Mean Δ | 95% boot CI | p (paired t) | p Holm | Sig. |
|---|---|---|---|---|---|---|
| Breast Cancer | SupCon (same enc.) | -0.004 | [-0.012, +0.004] | 0.4766 | 1.0000 | no |
| Breast Cancer | Triplet (batch-hard) | +0.000 | [-0.011, +0.009] | 1.0000 | 1.0000 | no |
| Breast Cancer | Proxy-Anchor | -0.002 | [-0.009, +0.005] | 0.7040 | 1.0000 | no |
| Breast Cancer | ArcFace | -0.002 | [-0.007, +0.004] | 0.6213 | 1.0000 | no |
| Breast Cancer | CosFace | -0.004 | [-0.012, +0.004] | 0.4766 | 1.0000 | no |
| Breast Cancer | CE-MLP (norm.) | -0.004 | [-0.012, +0.004] | 0.4766 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (tuned) | +0.007 | [-0.002, +0.016] | 0.2420 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (tuned, 16-D) | +0.004 | [-0.009, +0.016] | 0.6483 | 1.0000 | no |
| Breast Cancer | Sup-UMAP (default) | +0.007 | [-0.002, +0.016] | 0.2420 | 1.0000 | no |
| Breast Cancer | UMAP | +0.012 | [+0.005, +0.018] | 0.0249 | 0.3485 | no |
| Breast Cancer | LDA | +0.009 | [-0.005, +0.023] | 0.3262 | 1.0000 | no |
| Breast Cancer | PCA | +0.000 | [-0.011, +0.011] | 1.0000 | 1.0000 | no |
| Breast Cancer | t-SNE | +0.014 | [+0.004, +0.025] | 0.0777 | 1.0000 | no |
| Breast Cancer | PaCMAP | +0.028 | [+0.018, +0.037] | 0.0085 | 0.1275 | no |
| Breast Cancer | TriMap | +0.011 | [+0.000, +0.019] | 0.1447 | 1.0000 | no |
| Digits | SupCon (same enc.) | -0.014 | [-0.019, -0.008] | 0.0095 | 0.1238 | no |
| Digits | Triplet (batch-hard) | -0.007 | [-0.014, +0.000] | 0.1443 | 1.0000 | no |
| Digits | Proxy-Anchor | -0.011 | [-0.016, -0.005] | 0.0247 | 0.2471 | no |
| Digits | ArcFace | -0.014 | [-0.018, -0.011] | 0.0014 | 0.0215 | yes |
| Digits | CosFace | -0.013 | [-0.018, -0.007] | 0.0180 | 0.1983 | no |
| Digits | CE-MLP (norm.) | -0.016 | [-0.019, -0.011] | 0.0038 | 0.0531 | no |
| Digits | Sup-UMAP (tuned) | +0.023 | [+0.014, +0.032] | 0.0109 | 0.1312 | no |
| Digits | Sup-UMAP (tuned, 16-D) | +0.010 | [-0.003, +0.021] | 0.2175 | 1.0000 | no |
| Digits | Sup-UMAP (default) | +0.009 | [-0.004, +0.022] | 0.3058 | 1.0000 | no |
| Digits | UMAP | +0.006 | [-0.006, +0.014] | 0.3648 | 1.0000 | no |
| Digits | LDA | -0.004 | [-0.012, +0.001] | 0.3274 | 1.0000 | no |
| Digits | PCA | -0.002 | [-0.008, +0.004] | 0.5543 | 1.0000 | no |
| Digits | t-SNE | -0.009 | [-0.018, -0.001] | 0.1147 | 1.0000 | no |
| Digits | PaCMAP | -0.004 | [-0.012, +0.004] | 0.4543 | 1.0000 | no |
| Digits | TriMap | -0.001 | [-0.008, +0.006] | 0.8113 | 1.0000 | no |
| Mice Protein | SupCon (same enc.) | -0.026 | [-0.085, +0.033] | 0.4894 | 1.0000 | no |
| Mice Protein | Triplet (batch-hard) | -0.013 | [-0.039, +0.016] | 0.4661 | 1.0000 | no |
| Mice Protein | Proxy-Anchor | -0.012 | [-0.061, +0.036] | 0.6816 | 1.0000 | no |
| Mice Protein | ArcFace | +0.024 | [-0.023, +0.073] | 0.4431 | 1.0000 | no |
| Mice Protein | CosFace | +0.013 | [-0.031, +0.065] | 0.6486 | 1.0000 | no |
| Mice Protein | CE-MLP (norm.) | -0.013 | [-0.042, +0.018] | 0.4959 | 1.0000 | no |
| Mice Protein | Sup-UMAP (tuned) | +0.163 | [+0.135, +0.191] | 0.0006 | 0.0090 | yes |
| Mice Protein | Sup-UMAP (tuned, 16-D) | +0.133 | [+0.094, +0.164] | 0.0026 | 0.0363 | yes |
| Mice Protein | Sup-UMAP (default) | +0.157 | [+0.114, +0.196] | 0.0027 | 0.0363 | yes |
| Mice Protein | UMAP | +0.160 | [+0.099, +0.230] | 0.0127 | 0.1146 | no |
| Mice Protein | LDA | -0.047 | [-0.100, +0.011] | 0.2225 | 1.0000 | no |
| Mice Protein | PCA | +0.173 | [+0.115, +0.236] | 0.0060 | 0.0602 | no |
| Mice Protein | t-SNE | +0.121 | [+0.065, +0.189] | 0.0245 | 0.1957 | no |
| Mice Protein | PaCMAP | +0.187 | [+0.131, +0.242] | 0.0047 | 0.0515 | no |
| Mice Protein | TriMap | +0.155 | [+0.110, +0.198] | 0.0039 | 0.0467 | yes |
| Annealing | SupCon (same enc.) | -0.002 | [-0.008, +0.003] | 0.5415 | 1.0000 | no |
| Annealing | Triplet (batch-hard) | +0.001 | [-0.002, +0.004] | 0.6213 | 1.0000 | no |
| Annealing | Proxy-Anchor | -0.001 | [-0.012, +0.010] | 0.8712 | 1.0000 | no |
| Annealing | ArcFace | -0.008 | [-0.017, +0.001] | 0.2056 | 1.0000 | no |
| Annealing | CosFace | -0.006 | [-0.012, +0.001] | 0.2302 | 1.0000 | no |
| Annealing | CE-MLP (norm.) | -0.002 | [-0.008, +0.004] | 0.5870 | 1.0000 | no |
| Annealing | Sup-UMAP (tuned) | +0.050 | [+0.033, +0.067] | 0.0065 | 0.0523 | no |
| Annealing | Sup-UMAP (tuned, 16-D) | +0.051 | [+0.038, +0.064] | 0.0027 | 0.0283 | yes |
| Annealing | Sup-UMAP (default) | +0.044 | [+0.034, +0.054] | 0.0016 | 0.0206 | yes |
| Annealing | UMAP | +0.113 | [+0.087, +0.140] | 0.0020 | 0.0238 | yes |
| Annealing | LDA | +0.012 | [+0.003, +0.023] | 0.1084 | 0.7587 | no |
| Annealing | PCA | +0.042 | [+0.031, +0.054] | 0.0041 | 0.0372 | yes |
| Annealing | t-SNE | +0.054 | [+0.044, +0.067] | 0.0011 | 0.0149 | yes |
| Annealing | PaCMAP | +0.099 | [+0.071, +0.121] | 0.0026 | 0.0283 | yes |
| Annealing | TriMap | +0.107 | [+0.094, +0.118] | 0.0001 | 0.0015 | yes |
| COIL-20 | SupCon (same enc.) | -0.003 | [-0.008, +0.001] | 0.4050 | 0.9820 | no |
| COIL-20 | Triplet (batch-hard) | -0.006 | [-0.012, -0.001] | 0.1404 | 0.7018 | no |
| COIL-20 | Proxy-Anchor | -0.005 | [-0.012, +0.001] | 0.2455 | 0.9820 | no |
| COIL-20 | ArcFace | -0.003 | [-0.010, +0.001] | 0.3943 | 0.9820 | no |
| COIL-20 | CosFace | -0.004 | [-0.011, +0.000] | 0.2835 | 0.9820 | no |
| COIL-20 | CE-MLP (norm.) | -0.007 | [-0.013, -0.002] | 0.0890 | 0.5341 | no |
| COIL-20 | Sup-UMAP (tuned) | +0.048 | [+0.042, +0.053] | 0.0001 | 0.0017 | yes |
| COIL-20 | Sup-UMAP (tuned, 16-D) | +0.031 | [+0.023, +0.040] | 0.0037 | 0.0261 | yes |
| COIL-20 | Sup-UMAP (default) | +0.065 | [+0.055, +0.074] | 0.0003 | 0.0034 | yes |
| COIL-20 | UMAP | +0.142 | [+0.131, +0.150] | 0.0000 | 0.0002 | yes |
| COIL-20 | LDA | +0.082 | [+0.065, +0.096] | 0.0007 | 0.0063 | yes |
| COIL-20 | PCA | +0.024 | [+0.019, +0.028] | 0.0008 | 0.0063 | yes |
| COIL-20 | t-SNE | +0.047 | [+0.042, +0.053] | 0.0002 | 0.0017 | yes |
| COIL-20 | PaCMAP | +0.130 | [+0.121, +0.139] | 0.0000 | 0.0003 | yes |
| COIL-20 | TriMap | +0.137 | [+0.126, +0.151] | 0.0000 | 0.0006 | yes |
| CNAE-9 | SupCon (same enc.) | -0.004 | [-0.011, +0.003] | 0.4320 | 1.0000 | no |
| CNAE-9 | Triplet (batch-hard) | +0.002 | [-0.011, +0.018] | 0.8379 | 1.0000 | no |
| CNAE-9 | Proxy-Anchor | -0.011 | [-0.020, -0.002] | 0.1087 | 0.6522 | no |
| CNAE-9 | ArcFace | -0.005 | [-0.012, +0.003] | 0.3513 | 1.0000 | no |
| CNAE-9 | CosFace | -0.005 | [-0.009, +0.003] | 0.2663 | 1.0000 | no |
| CNAE-9 | CE-MLP (norm.) | -0.013 | [-0.024, -0.000] | 0.1281 | 0.6522 | no |
| CNAE-9 | Sup-UMAP (tuned) | +0.090 | [+0.056, +0.134] | 0.0173 | 0.1386 | no |
| CNAE-9 | Sup-UMAP (tuned, 16-D) | +0.084 | [+0.049, +0.131] | 0.0227 | 0.1591 | no |
| CNAE-9 | Sup-UMAP (default) | +0.075 | [+0.061, +0.089] | 0.0009 | 0.0134 | yes |
| CNAE-9 | UMAP | +0.107 | [+0.085, +0.135] | 0.0019 | 0.0231 | yes |
| CNAE-9 | LDA | +0.086 | [+0.062, +0.111] | 0.0040 | 0.0399 | yes |
| CNAE-9 | PCA | +0.130 | [+0.106, +0.161] | 0.0013 | 0.0187 | yes |
| CNAE-9 | t-SNE | +0.143 | [+0.108, +0.181] | 0.0017 | 0.0227 | yes |
| CNAE-9 | PaCMAP | +0.109 | [+0.071, +0.144] | 0.0061 | 0.0549 | no |
| CNAE-9 | TriMap | +0.124 | [+0.090, +0.158] | 0.0033 | 0.0362 | yes |
| MNIST | SupCon (same enc.) | -0.006 | [-0.008, -0.004] | 0.0078 | 0.0303 | yes |
| MNIST | Triplet (batch-hard) | -0.008 | [-0.011, -0.005] | 0.0076 | 0.0303 | yes |
| MNIST | Proxy-Anchor | -0.008 | [-0.011, -0.006] | 0.0057 | 0.0283 | yes |
| MNIST | ArcFace | -0.005 | [-0.007, -0.003] | 0.0150 | 0.0303 | yes |
| MNIST | CosFace | -0.006 | [-0.010, -0.003] | 0.0327 | 0.0327 | yes |
| MNIST | CE-MLP (norm.) | -0.010 | [-0.012, -0.009] | 0.0005 | 0.0028 | yes |
| MNIST | Sup-UMAP (tuned) | +0.035 | [+0.031, +0.039] | 0.0001 | 0.0009 | yes |
| MNIST | Sup-UMAP (tuned, 16-D) | +0.029 | [+0.025, +0.033] | 0.0002 | 0.0017 | yes |
| MNIST | Sup-UMAP (default) | +0.035 | [+0.031, +0.039] | 0.0001 | 0.0009 | yes |
| MNIST | UMAP | +0.073 | [+0.067, +0.079] | 0.0000 | 0.0004 | yes |
| MNIST | LDA | +0.072 | [+0.071, +0.074] | 0.0000 | 0.0000 | yes |
| MNIST | PCA | +0.036 | [+0.032, +0.041] | 0.0001 | 0.0012 | yes |
| MNIST | t-SNE | +0.056 | [+0.052, +0.061] | 0.0000 | 0.0004 | yes |
| MNIST | PaCMAP | +0.082 | [+0.080, +0.084] | 0.0000 | 0.0000 | yes |
| MNIST | TriMap | +0.096 | [+0.084, +0.110] | 0.0002 | 0.0017 | yes |
| Fashion-MNIST | SupCon (same enc.) | -0.002 | [-0.005, +0.001] | 0.3820 | 0.7641 | no |
| Fashion-MNIST | Triplet (batch-hard) | +0.007 | [+0.002, +0.011] | 0.0544 | 0.3177 | no |
| Fashion-MNIST | Proxy-Anchor | -0.007 | [-0.011, -0.002] | 0.0530 | 0.3177 | no |
| Fashion-MNIST | ArcFace | +0.004 | [-0.001, +0.009] | 0.2150 | 0.6451 | no |
| Fashion-MNIST | CosFace | -0.001 | [-0.003, +0.002] | 0.7790 | 0.7790 | no |
| Fashion-MNIST | CE-MLP (norm.) | -0.007 | [-0.012, -0.002] | 0.0670 | 0.3177 | no |
| Fashion-MNIST | Sup-UMAP (tuned) | +0.056 | [+0.049, +0.066] | 0.0004 | 0.0038 | yes |
| Fashion-MNIST | Sup-UMAP (tuned, 16-D) | +0.052 | [+0.043, +0.062] | 0.0008 | 0.0058 | yes |
| Fashion-MNIST | Sup-UMAP (default) | +0.056 | [+0.049, +0.066] | 0.0004 | 0.0038 | yes |
| Fashion-MNIST | UMAP | +0.129 | [+0.118, +0.141] | 0.0000 | 0.0005 | yes |
| Fashion-MNIST | LDA | +0.056 | [+0.048, +0.064] | 0.0003 | 0.0029 | yes |
| Fashion-MNIST | PCA | +0.066 | [+0.056, +0.076] | 0.0004 | 0.0038 | yes |
| Fashion-MNIST | t-SNE | +0.063 | [+0.055, +0.071] | 0.0002 | 0.0028 | yes |
| Fashion-MNIST | PaCMAP | +0.119 | [+0.110, +0.130] | 0.0000 | 0.0004 | yes |
| Fashion-MNIST | TriMap | +0.121 | [+0.115, +0.128] | 0.0000 | 0.0001 | yes |
| HAR | SupCon (same enc.) | +0.001 | [-0.001, +0.002] | 0.3072 | 0.9216 | no |
| HAR | Triplet (batch-hard) | -0.001 | [-0.002, +0.000] | 0.2070 | 0.8282 | no |
| HAR | Proxy-Anchor | -0.001 | [-0.003, +0.001] | 0.6535 | 0.9216 | no |
| HAR | ArcFace | +0.002 | [+0.001, +0.003] | 0.0247 | 0.1483 | no |
| HAR | CosFace | +0.002 | [+0.000, +0.004] | 0.1398 | 0.6992 | no |
| HAR | CE-MLP (norm.) | -0.001 | [-0.003, +0.001] | 0.4418 | 0.9216 | no |
| HAR | Sup-UMAP (tuned) | +0.037 | [+0.032, +0.041] | 0.0001 | 0.0010 | yes |
| HAR | Sup-UMAP (tuned, 16-D) | +0.035 | [+0.032, +0.037] | 0.0000 | 0.0003 | yes |
| HAR | Sup-UMAP (default) | +0.057 | [+0.047, +0.064] | 0.0003 | 0.0028 | yes |
| HAR | UMAP | +0.119 | [+0.113, +0.125] | 0.0000 | 0.0001 | yes |
| HAR | LDA | +0.006 | [+0.005, +0.008] | 0.0039 | 0.0272 | yes |
| HAR | PCA | +0.087 | [+0.080, +0.093] | 0.0000 | 0.0002 | yes |
| HAR | t-SNE | +0.038 | [+0.035, +0.041] | 0.0000 | 0.0002 | yes |
| HAR | PaCMAP | +0.103 | [+0.096, +0.109] | 0.0000 | 0.0001 | yes |
| HAR | TriMap | +0.119 | [+0.115, +0.123] | 0.0000 | 0.0000 | yes |
| ISOLET | SupCon (same enc.) | +0.001 | [-0.001, +0.003] | 0.2859 | 1.0000 | no |
| ISOLET | Triplet (batch-hard) | +0.001 | [-0.001, +0.004] | 0.4363 | 1.0000 | no |
| ISOLET | Proxy-Anchor | -0.001 | [-0.002, +0.001] | 0.3111 | 1.0000 | no |
| ISOLET | ArcFace | +0.003 | [-0.000, +0.006] | 0.1810 | 0.9051 | no |
| ISOLET | CosFace | +0.001 | [-0.001, +0.003] | 0.3380 | 1.0000 | no |
| ISOLET | CE-MLP (norm.) | -0.005 | [-0.007, -0.004] | 0.0031 | 0.0183 | yes |
| ISOLET | Sup-UMAP (tuned) | +0.097 | [+0.089, +0.104] | 0.0000 | 0.0002 | yes |
| ISOLET | Sup-UMAP (tuned, 16-D) | +0.091 | [+0.082, +0.098] | 0.0000 | 0.0003 | yes |
| ISOLET | Sup-UMAP (default) | +0.105 | [+0.097, +0.113] | 0.0000 | 0.0002 | yes |
| ISOLET | UMAP | +0.211 | [+0.205, +0.219] | 0.0000 | 0.0000 | yes |
| ISOLET | LDA | +0.043 | [+0.036, +0.049] | 0.0003 | 0.0023 | yes |
| ISOLET | PCA | +0.190 | [+0.182, +0.194] | 0.0000 | 0.0000 | yes |
| ISOLET | t-SNE | +0.154 | [+0.149, +0.160] | 0.0000 | 0.0000 | yes |
| ISOLET | PaCMAP | +0.219 | [+0.206, +0.233] | 0.0000 | 0.0001 | yes |
| ISOLET | TriMap | +0.210 | [+0.206, +0.213] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | SupCon (same enc.) | -0.060 | [-0.073, -0.043] | 0.0028 | 0.0199 | yes |
| Olivetti Faces | Triplet (batch-hard) | -0.053 | [-0.073, -0.035] | 0.0081 | 0.0489 | yes |
| Olivetti Faces | Proxy-Anchor | -0.050 | [-0.068, -0.030] | 0.0111 | 0.0553 | no |
| Olivetti Faces | ArcFace | -0.022 | [-0.043, +0.003] | 0.1671 | 0.3342 | no |
| Olivetti Faces | CosFace | -0.025 | [-0.043, -0.003] | 0.0890 | 0.2670 | no |
| Olivetti Faces | CE-MLP (norm.) | -0.035 | [-0.052, -0.015] | 0.0312 | 0.1249 | no |
| Olivetti Faces | Sup-UMAP (tuned) | +0.277 | [+0.237, +0.310] | 0.0002 | 0.0020 | yes |
| Olivetti Faces | Sup-UMAP (tuned, 16-D) | +0.257 | [+0.217, +0.295] | 0.0003 | 0.0037 | yes |
| Olivetti Faces | Sup-UMAP (default) | +0.428 | [+0.403, +0.455] | 0.0000 | 0.0002 | yes |
| Olivetti Faces | UMAP | +0.495 | [+0.460, +0.530] | 0.0000 | 0.0002 | yes |
| Olivetti Faces | LDA | -0.028 | [-0.055, +0.000] | 0.1707 | 0.3342 | no |
| Olivetti Faces | PCA | +0.240 | [+0.202, +0.277] | 0.0004 | 0.0038 | yes |
| Olivetti Faces | t-SNE | +0.192 | [+0.150, +0.235] | 0.0015 | 0.0120 | yes |
| Olivetti Faces | PaCMAP | +0.307 | [+0.260, +0.355] | 0.0004 | 0.0038 | yes |
| Olivetti Faces | TriMap | +0.353 | [+0.310, +0.395] | 0.0002 | 0.0020 | yes |
