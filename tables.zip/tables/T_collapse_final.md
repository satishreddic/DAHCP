Angular-collapse diagnostics at the last epoch (training monitor subset, mean over 5 runs). Resultant length 1.0 = all embeddings share one direction; effective rank ≤ 16.

| Dataset | full: resultant | full: cos var | full: eff. rank | no_sphere: resultant | no_sphere: cos var | no_sphere: eff. rank |
|---|---|---|---|---|---|---|
| Breast Cancer | 0.655 | 0.372 | 3.12 | 0.553 | 0.503 | 5.81 |
| Digits | 0.437 | 0.194 | 7.70 | 0.585 | 0.123 | 8.89 |
| Mice Protein | 0.276 | 0.295 | 6.29 | 0.484 | 0.217 | 7.40 |
| Annealing | 0.639 | 0.552 | 5.60 | 0.804 | 0.181 | 6.82 |
| COIL-20 | 0.186 | 0.213 | 7.91 | 0.696 | 0.084 | 8.28 |
| CNAE-9 | 0.433 | 0.196 | 6.75 | 0.823 | 0.039 | 5.91 |
| MNIST | 0.027 | 0.111 | 9.13 | 0.430 | 0.181 | 6.03 |
| Fashion-MNIST | 0.372 | 0.225 | 6.79 | 0.537 | 0.143 | 6.03 |
| HAR | 0.589 | 0.133 | 5.51 | 0.632 | 0.092 | 5.76 |
| ISOLET | 0.031 | 0.069 | 15.70 | 0.639 | 0.081 | 8.61 |
| Olivetti Faces | 0.266 | 0.181 | 9.02 | 0.537 | 0.133 | 9.71 |
