Average rank on Test linear-probe accuracy (1 = best).

| Method | Average rank |
|---|---|
| CE-MLP (norm.) | 2.0 |
| Proxy-Anchor | 2.32 |
| SupCon (same enc.) | 4.32 |
| Triplet (batch-hard) | 4.64 |
| ArcFace | 4.68 |
| CosFace | 4.73 |
| DACHP (ours) | 5.64 |
| Sup-UMAP (tuned, 16-D) | 8.91 |
| LDA | 9.27 |
| PCA | 10.14 |
| Sup-UMAP (default) | 10.77 |
| Sup-UMAP (tuned) | 11.5 |
| TriMap | 14.0 |
| UMAP | 14.09 |
| PaCMAP | 14.36 |
| t-SNE | 14.64 |
