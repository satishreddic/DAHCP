Label-permutation control: DACHP trained on randomly permuted TRAINING labels; the 5-NN probe is then fitted on the true training labels and scored on the true test labels (5 permutations). Accuracy that stays high indicates class structure already present in the input and preserved by the encoder; accuracy at chance indicates that the structure was learned from the labels.

| Dataset | True labels | Permuted train labels | Majority-class rate | Uniform chance |
|---|---|---|---|---|
| Breast Cancer | 0.972 | 0.912 ± 0.028 | 0.627 | 0.500 |
| Digits | 0.961 | 0.914 ± 0.026 | 0.102 | 0.100 |
| Mice Protein | 0.490 | 0.306 ± 0.060 | 0.139 | 0.125 |
| Annealing | 0.974 | 0.862 ± 0.030 | 0.762 | 0.200 |
| COIL-20 | 0.992 | 0.923 ± 0.024 | 0.050 | 0.050 |
| CNAE-9 | 0.925 | 0.192 ± 0.035 | 0.111 | 0.111 |
| MNIST | 0.940 | 0.099 ± 0.006 | 0.100 | 0.100 |
| Fashion-MNIST | 0.853 | 0.103 ± 0.003 | 0.100 | 0.100 |
| HAR | 0.988 | 0.192 ± 0.017 | 0.189 | 0.167 |
| ISOLET | 0.968 | 0.044 ± 0.006 | 0.038 | 0.038 |
| Olivetti Faces | 0.910 | 0.110 ± 0.044 | 0.025 | 0.025 |
