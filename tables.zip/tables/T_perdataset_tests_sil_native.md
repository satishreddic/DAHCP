Per-dataset paired comparison of DACHP (ours) vs each method on Test Silhouette (native dim.) over the 5 held-out splits; Holm correction across methods within each dataset.

| Dataset | vs | Mean Δ | 95% boot CI | p (paired t) | p Holm | Sig. |
|---|---|---|---|---|---|---|
| Breast Cancer | SupCon (same enc.) | +0.056 | [+0.041, +0.071] | 0.0032 | 0.0226 | yes |
| Breast Cancer | Triplet (batch-hard) | +0.000 | [-0.018, +0.019] | 0.9712 | 0.9712 | no |
| Breast Cancer | Proxy-Anchor | +0.039 | [+0.023, +0.056] | 0.0136 | 0.0678 | no |
| Breast Cancer | ArcFace | +0.051 | [+0.045, +0.058] | 0.0002 | 0.0015 | yes |
| Breast Cancer | CosFace | +0.118 | [+0.108, +0.129] | 0.0000 | 0.0005 | yes |
| Breast Cancer | CE-MLP (norm.) | +0.058 | [+0.041, +0.075] | 0.0041 | 0.0243 | yes |
| Breast Cancer | Sup-UMAP (tuned) | +0.084 | [+0.033, +0.140] | 0.0523 | 0.2091 | no |
| Breast Cancer | Sup-UMAP (tuned, 16-D) | +0.012 | [-0.008, +0.029] | 0.3434 | 0.6868 | no |
| Breast Cancer | Sup-UMAP (default) | +0.084 | [+0.033, +0.140] | 0.0523 | 0.2091 | no |
| Breast Cancer | UMAP | +0.336 | [+0.305, +0.368] | 0.0001 | 0.0006 | yes |
| Breast Cancer | LDA | +0.191 | [+0.170, +0.208] | 0.0001 | 0.0006 | yes |
| Breast Cancer | PCA | +0.542 | [+0.517, +0.567] | 0.0000 | 0.0000 | yes |
| Breast Cancer | t-SNE | +0.343 | [+0.321, +0.376] | 0.0000 | 0.0004 | yes |
| Breast Cancer | PaCMAP | +0.353 | [+0.323, +0.385] | 0.0000 | 0.0005 | yes |
| Breast Cancer | TriMap | +0.279 | [+0.236, +0.321] | 0.0004 | 0.0030 | yes |
| Digits | SupCon (same enc.) | -0.060 | [-0.074, -0.047] | 0.0013 | 0.0093 | yes |
| Digits | Triplet (batch-hard) | +0.161 | [+0.153, +0.168] | 0.0000 | 0.0000 | yes |
| Digits | Proxy-Anchor | -0.008 | [-0.014, -0.003] | 0.0570 | 0.0570 | no |
| Digits | ArcFace | +0.073 | [+0.063, +0.083] | 0.0002 | 0.0024 | yes |
| Digits | CosFace | +0.043 | [+0.033, +0.053] | 0.0015 | 0.0093 | yes |
| Digits | CE-MLP (norm.) | +0.155 | [+0.138, +0.176] | 0.0001 | 0.0017 | yes |
| Digits | Sup-UMAP (tuned) | -0.081 | [-0.097, -0.059] | 0.0019 | 0.0097 | yes |
| Digits | Sup-UMAP (tuned, 16-D) | -0.170 | [-0.207, -0.143] | 0.0009 | 0.0075 | yes |
| Digits | Sup-UMAP (default) | -0.077 | [-0.120, -0.041] | 0.0265 | 0.0530 | no |
| Digits | UMAP | +0.081 | [+0.055, +0.102] | 0.0039 | 0.0156 | yes |
| Digits | LDA | +0.272 | [+0.259, +0.284] | 0.0000 | 0.0000 | yes |
| Digits | PCA | +0.474 | [+0.456, +0.493] | 0.0000 | 0.0000 | yes |
| Digits | t-SNE | +0.137 | [+0.118, +0.157] | 0.0002 | 0.0024 | yes |
| Digits | PaCMAP | +0.085 | [+0.054, +0.115] | 0.0089 | 0.0267 | yes |
| Digits | TriMap | +0.140 | [+0.120, +0.161] | 0.0003 | 0.0028 | yes |
| Mice Protein | SupCon (same enc.) | -0.031 | [-0.067, +0.009] | 0.2254 | 1.0000 | no |
| Mice Protein | Triplet (batch-hard) | -0.052 | [-0.082, -0.026] | 0.0357 | 0.3570 | no |
| Mice Protein | Proxy-Anchor | -0.050 | [-0.076, -0.024] | 0.0276 | 0.3031 | no |
| Mice Protein | ArcFace | -0.032 | [-0.066, +0.016] | 0.2630 | 1.0000 | no |
| Mice Protein | CosFace | -0.037 | [-0.070, +0.005] | 0.1605 | 0.9837 | no |
| Mice Protein | CE-MLP (norm.) | -0.035 | [-0.066, +0.002] | 0.1405 | 0.9837 | no |
| Mice Protein | Sup-UMAP (tuned) | +0.224 | [+0.187, +0.266] | 0.0006 | 0.0075 | yes |
| Mice Protein | Sup-UMAP (tuned, 16-D) | +0.082 | [+0.029, +0.142] | 0.0627 | 0.5037 | no |
| Mice Protein | Sup-UMAP (default) | +0.227 | [+0.199, +0.254] | 0.0001 | 0.0019 | yes |
| Mice Protein | UMAP | +0.244 | [+0.211, +0.277] | 0.0002 | 0.0030 | yes |
| Mice Protein | LDA | -0.064 | [-0.100, -0.041] | 0.0229 | 0.2749 | no |
| Mice Protein | PCA | +0.050 | [+0.020, +0.084] | 0.0560 | 0.5037 | no |
| Mice Protein | t-SNE | +0.019 | [-0.027, +0.065] | 0.5032 | 1.0000 | no |
| Mice Protein | PaCMAP | -0.002 | [-0.056, +0.073] | 0.9651 | 1.0000 | no |
| Mice Protein | TriMap | +0.006 | [-0.035, +0.062] | 0.8427 | 1.0000 | no |
| Annealing | SupCon (same enc.) | +0.015 | [-0.058, +0.089] | 0.7368 | 0.7368 | no |
| Annealing | Triplet (batch-hard) | +0.274 | [+0.179, +0.369] | 0.0077 | 0.0459 | yes |
| Annealing | Proxy-Anchor | +0.154 | [+0.043, +0.257] | 0.0685 | 0.1370 | no |
| Annealing | ArcFace | +0.188 | [+0.105, +0.259] | 0.0149 | 0.0595 | no |
| Annealing | CosFace | +0.256 | [+0.150, +0.352] | 0.0111 | 0.0555 | no |
| Annealing | CE-MLP (norm.) | +0.338 | [+0.183, +0.480] | 0.0175 | 0.0595 | no |
| Annealing | Sup-UMAP (tuned) | +0.554 | [+0.427, +0.682] | 0.0016 | 0.0163 | yes |
| Annealing | Sup-UMAP (tuned, 16-D) | +0.500 | [+0.335, +0.640] | 0.0050 | 0.0347 | yes |
| Annealing | Sup-UMAP (default) | +0.570 | [+0.417, +0.713] | 0.0026 | 0.0235 | yes |
| Annealing | UMAP | +0.874 | [+0.721, +1.028] | 0.0007 | 0.0080 | yes |
| Annealing | LDA | +0.326 | [+0.230, +0.423] | 0.0042 | 0.0334 | yes |
| Annealing | PCA | +0.711 | [+0.572, +0.855] | 0.0010 | 0.0105 | yes |
| Annealing | t-SNE | +0.865 | [+0.741, +0.979] | 0.0002 | 0.0030 | yes |
| Annealing | PaCMAP | +0.913 | [+0.794, +1.030] | 0.0002 | 0.0027 | yes |
| Annealing | TriMap | +0.917 | [+0.770, +1.048] | 0.0003 | 0.0042 | yes |
| COIL-20 | SupCon (same enc.) | -0.044 | [-0.060, -0.033] | 0.0052 | 0.0157 | yes |
| COIL-20 | Triplet (batch-hard) | +0.001 | [-0.018, +0.014] | 0.9393 | 0.9393 | no |
| COIL-20 | Proxy-Anchor | -0.068 | [-0.081, -0.057] | 0.0006 | 0.0037 | yes |
| COIL-20 | ArcFace | +0.101 | [+0.087, +0.114] | 0.0002 | 0.0016 | yes |
| COIL-20 | CosFace | +0.054 | [+0.038, +0.067] | 0.0031 | 0.0126 | yes |
| COIL-20 | CE-MLP (norm.) | +0.101 | [+0.083, +0.116] | 0.0005 | 0.0033 | yes |
| COIL-20 | Sup-UMAP (tuned) | +0.465 | [+0.429, +0.520] | 0.0001 | 0.0006 | yes |
| COIL-20 | Sup-UMAP (tuned, 16-D) | +0.054 | [+0.025, +0.082] | 0.0337 | 0.0673 | no |
| COIL-20 | Sup-UMAP (default) | +0.154 | [+0.124, +0.179] | 0.0007 | 0.0037 | yes |
| COIL-20 | UMAP | +0.344 | [+0.316, +0.364] | 0.0000 | 0.0002 | yes |
| COIL-20 | LDA | +0.453 | [+0.421, +0.485] | 0.0000 | 0.0002 | yes |
| COIL-20 | PCA | +0.560 | [+0.543, +0.579] | 0.0000 | 0.0000 | yes |
| COIL-20 | t-SNE | +0.428 | [+0.401, +0.451] | 0.0000 | 0.0001 | yes |
| COIL-20 | PaCMAP | +0.245 | [+0.222, +0.267] | 0.0000 | 0.0005 | yes |
| COIL-20 | TriMap | +0.352 | [+0.337, +0.366] | 0.0000 | 0.0000 | yes |
| CNAE-9 | SupCon (same enc.) | -0.012 | [-0.018, -0.005] | 0.0279 | 0.0558 | no |
| CNAE-9 | Triplet (batch-hard) | +0.052 | [+0.047, +0.058] | 0.0001 | 0.0008 | yes |
| CNAE-9 | Proxy-Anchor | +0.004 | [+0.001, +0.007] | 0.0774 | 0.0774 | no |
| CNAE-9 | ArcFace | +0.166 | [+0.160, +0.172] | 0.0000 | 0.0000 | yes |
| CNAE-9 | CosFace | +0.079 | [+0.070, +0.085] | 0.0001 | 0.0006 | yes |
| CNAE-9 | CE-MLP (norm.) | +0.117 | [+0.106, +0.129] | 0.0001 | 0.0006 | yes |
| CNAE-9 | Sup-UMAP (tuned) | +0.225 | [+0.185, +0.278] | 0.0011 | 0.0043 | yes |
| CNAE-9 | Sup-UMAP (tuned, 16-D) | +0.147 | [+0.111, +0.193] | 0.0037 | 0.0112 | yes |
| CNAE-9 | Sup-UMAP (default) | +0.142 | [+0.114, +0.164] | 0.0006 | 0.0028 | yes |
| CNAE-9 | UMAP | +0.316 | [+0.299, +0.337] | 0.0000 | 0.0001 | yes |
| CNAE-9 | LDA | +0.405 | [+0.362, +0.455] | 0.0001 | 0.0008 | yes |
| CNAE-9 | PCA | +0.638 | [+0.599, +0.677] | 0.0000 | 0.0001 | yes |
| CNAE-9 | t-SNE | +0.607 | [+0.578, +0.632] | 0.0000 | 0.0000 | yes |
| CNAE-9 | PaCMAP | +0.346 | [+0.295, +0.395] | 0.0003 | 0.0016 | yes |
| CNAE-9 | TriMap | +0.398 | [+0.374, +0.421] | 0.0000 | 0.0001 | yes |
| MNIST | SupCon (same enc.) | +0.029 | [+0.021, +0.036] | 0.0029 | 0.0029 | yes |
| MNIST | Triplet (batch-hard) | +0.152 | [+0.140, +0.159] | 0.0000 | 0.0001 | yes |
| MNIST | Proxy-Anchor | +0.040 | [+0.032, +0.048] | 0.0010 | 0.0020 | yes |
| MNIST | ArcFace | +0.198 | [+0.190, +0.204] | 0.0000 | 0.0000 | yes |
| MNIST | CosFace | +0.155 | [+0.147, +0.164] | 0.0000 | 0.0000 | yes |
| MNIST | CE-MLP (norm.) | +0.145 | [+0.138, +0.151] | 0.0000 | 0.0000 | yes |
| MNIST | Sup-UMAP (tuned) | +0.208 | [+0.185, +0.231] | 0.0001 | 0.0004 | yes |
| MNIST | Sup-UMAP (tuned, 16-D) | +0.105 | [+0.092, +0.119] | 0.0002 | 0.0005 | yes |
| MNIST | Sup-UMAP (default) | +0.208 | [+0.185, +0.231] | 0.0001 | 0.0004 | yes |
| MNIST | UMAP | +0.523 | [+0.514, +0.531] | 0.0000 | 0.0000 | yes |
| MNIST | LDA | +0.627 | [+0.597, +0.672] | 0.0000 | 0.0001 | yes |
| MNIST | PCA | +0.754 | [+0.746, +0.759] | 0.0000 | 0.0000 | yes |
| MNIST | t-SNE | +0.658 | [+0.639, +0.671] | 0.0000 | 0.0000 | yes |
| MNIST | PaCMAP | +0.552 | [+0.525, +0.583] | 0.0000 | 0.0000 | yes |
| MNIST | TriMap | +0.598 | [+0.576, +0.621] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | SupCon (same enc.) | +0.005 | [-0.002, +0.010] | 0.2367 | 0.4734 | no |
| Fashion-MNIST | Triplet (batch-hard) | +0.349 | [+0.307, +0.391] | 0.0001 | 0.0006 | yes |
| Fashion-MNIST | Proxy-Anchor | -0.002 | [-0.008, +0.005] | 0.6446 | 0.6446 | no |
| Fashion-MNIST | ArcFace | +0.229 | [+0.220, +0.238] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | CosFace | +0.113 | [+0.106, +0.123] | 0.0000 | 0.0002 | yes |
| Fashion-MNIST | CE-MLP (norm.) | +0.115 | [+0.103, +0.128] | 0.0001 | 0.0005 | yes |
| Fashion-MNIST | Sup-UMAP (tuned) | +0.206 | [+0.184, +0.229] | 0.0001 | 0.0006 | yes |
| Fashion-MNIST | Sup-UMAP (tuned, 16-D) | +0.135 | [+0.116, +0.158] | 0.0004 | 0.0011 | yes |
| Fashion-MNIST | Sup-UMAP (default) | +0.206 | [+0.184, +0.229] | 0.0001 | 0.0006 | yes |
| Fashion-MNIST | UMAP | +0.393 | [+0.376, +0.412] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | LDA | +0.350 | [+0.335, +0.365] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | PCA | +0.515 | [+0.501, +0.528] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | t-SNE | +0.415 | [+0.402, +0.430] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | PaCMAP | +0.385 | [+0.367, +0.403] | 0.0000 | 0.0000 | yes |
| Fashion-MNIST | TriMap | +0.410 | [+0.398, +0.423] | 0.0000 | 0.0000 | yes |
| HAR | SupCon (same enc.) | +0.032 | [+0.030, +0.034] | 0.0000 | 0.0001 | yes |
| HAR | Triplet (batch-hard) | +0.119 | [+0.103, +0.134] | 0.0002 | 0.0002 | yes |
| HAR | Proxy-Anchor | +0.064 | [+0.060, +0.068] | 0.0000 | 0.0001 | yes |
| HAR | ArcFace | +0.255 | [+0.246, +0.265] | 0.0000 | 0.0000 | yes |
| HAR | CosFace | +0.138 | [+0.132, +0.143] | 0.0000 | 0.0000 | yes |
| HAR | CE-MLP (norm.) | +0.148 | [+0.145, +0.152] | 0.0000 | 0.0000 | yes |
| HAR | Sup-UMAP (tuned) | +0.233 | [+0.207, +0.254] | 0.0001 | 0.0002 | yes |
| HAR | Sup-UMAP (tuned, 16-D) | +0.164 | [+0.153, +0.175] | 0.0000 | 0.0001 | yes |
| HAR | Sup-UMAP (default) | +0.258 | [+0.233, +0.284] | 0.0001 | 0.0002 | yes |
| HAR | UMAP | +0.695 | [+0.680, +0.712] | 0.0000 | 0.0000 | yes |
| HAR | LDA | +0.319 | [+0.312, +0.324] | 0.0000 | 0.0000 | yes |
| HAR | PCA | +0.863 | [+0.854, +0.871] | 0.0000 | 0.0000 | yes |
| HAR | t-SNE | +0.683 | [+0.670, +0.694] | 0.0000 | 0.0000 | yes |
| HAR | PaCMAP | +0.688 | [+0.667, +0.717] | 0.0000 | 0.0000 | yes |
| HAR | TriMap | +0.718 | [+0.709, +0.726] | 0.0000 | 0.0000 | yes |
| ISOLET | SupCon (same enc.) | +0.007 | [-0.000, +0.017] | 0.2205 | 0.2205 | no |
| ISOLET | Triplet (batch-hard) | +0.210 | [+0.205, +0.213] | 0.0000 | 0.0000 | yes |
| ISOLET | Proxy-Anchor | -0.004 | [-0.006, -0.001] | 0.0694 | 0.1389 | no |
| ISOLET | ArcFace | +0.307 | [+0.301, +0.312] | 0.0000 | 0.0000 | yes |
| ISOLET | CosFace | +0.258 | [+0.257, +0.260] | 0.0000 | 0.0000 | yes |
| ISOLET | CE-MLP (norm.) | +0.076 | [+0.074, +0.078] | 0.0000 | 0.0000 | yes |
| ISOLET | Sup-UMAP (tuned) | +0.418 | [+0.399, +0.438] | 0.0000 | 0.0000 | yes |
| ISOLET | Sup-UMAP (tuned, 16-D) | +0.279 | [+0.270, +0.289] | 0.0000 | 0.0000 | yes |
| ISOLET | Sup-UMAP (default) | +0.345 | [+0.328, +0.360] | 0.0000 | 0.0000 | yes |
| ISOLET | UMAP | +0.651 | [+0.638, +0.665] | 0.0000 | 0.0000 | yes |
| ISOLET | LDA | +0.558 | [+0.550, +0.565] | 0.0000 | 0.0000 | yes |
| ISOLET | PCA | +0.773 | [+0.765, +0.781] | 0.0000 | 0.0000 | yes |
| ISOLET | t-SNE | +0.669 | [+0.662, +0.675] | 0.0000 | 0.0000 | yes |
| ISOLET | PaCMAP | +0.649 | [+0.639, +0.657] | 0.0000 | 0.0000 | yes |
| ISOLET | TriMap | +0.653 | [+0.648, +0.658] | 0.0000 | 0.0000 | yes |
| Olivetti Faces | SupCon (same enc.) | -0.137 | [-0.161, -0.111] | 0.0007 | 0.0061 | yes |
| Olivetti Faces | Triplet (batch-hard) | -0.096 | [-0.125, -0.067] | 0.0048 | 0.0285 | yes |
| Olivetti Faces | Proxy-Anchor | -0.099 | [-0.130, -0.070] | 0.0052 | 0.0285 | yes |
| Olivetti Faces | ArcFace | +0.082 | [+0.046, +0.118] | 0.0161 | 0.0484 | yes |
| Olivetti Faces | CosFace | +0.004 | [-0.028, +0.036] | 0.8345 | 0.8345 | no |
| Olivetti Faces | CE-MLP (norm.) | +0.022 | [-0.010, +0.055] | 0.3092 | 0.6184 | no |
| Olivetti Faces | Sup-UMAP (tuned) | +0.337 | [+0.234, +0.442] | 0.0050 | 0.0285 | yes |
| Olivetti Faces | Sup-UMAP (tuned, 16-D) | +0.230 | [+0.185, +0.295] | 0.0020 | 0.0160 | yes |
| Olivetti Faces | Sup-UMAP (default) | +0.485 | [+0.438, +0.536] | 0.0001 | 0.0010 | yes |
| Olivetti Faces | UMAP | +0.626 | [+0.573, +0.682] | 0.0000 | 0.0005 | yes |
| Olivetti Faces | LDA | +0.122 | [+0.090, +0.152] | 0.0025 | 0.0174 | yes |
| Olivetti Faces | PCA | +0.365 | [+0.346, +0.385] | 0.0000 | 0.0001 | yes |
| Olivetti Faces | t-SNE | +0.355 | [+0.296, +0.406] | 0.0003 | 0.0035 | yes |
| Olivetti Faces | PaCMAP | +0.343 | [+0.296, +0.393] | 0.0003 | 0.0028 | yes |
| Olivetti Faces | TriMap | +0.406 | [+0.362, +0.450] | 0.0001 | 0.0011 | yes |
